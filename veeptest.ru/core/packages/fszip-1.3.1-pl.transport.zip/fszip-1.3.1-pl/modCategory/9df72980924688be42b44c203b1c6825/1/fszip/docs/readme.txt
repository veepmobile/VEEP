--------------------
Extra: fsZIP
--------------------
Version: 1.2 (15.11.2016)
Since: January 27th, 2014
Author: Vadim Rudnitskiy <griveh@rambler.ru>, Igor Siluyanov <olvin.hh@yandex.ru>
