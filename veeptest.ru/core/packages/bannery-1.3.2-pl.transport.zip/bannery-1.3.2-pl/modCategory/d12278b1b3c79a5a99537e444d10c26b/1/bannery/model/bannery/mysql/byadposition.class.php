<?php
require_once (dirname(dirname(__FILE__)) . '/byadposition.class.php');
class byAdPosition_mysql extends byAdPosition {}