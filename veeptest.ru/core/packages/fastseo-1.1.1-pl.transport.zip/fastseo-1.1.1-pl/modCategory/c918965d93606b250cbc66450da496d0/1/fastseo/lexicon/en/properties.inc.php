<?php
/**
 * @package fastseo
 * @subpackage lexicon
 */
$_lang['prop_fastseo.ascending'] = 'Ascending';
$_lang['prop_fastseo.descending'] = 'Descending';
$_lang['prop_fastseo.dir_desc'] = 'The direction to sort by.';
$_lang['prop_fastseo.sort_desc'] = 'The field to sort by.';
$_lang['prop_fastseo.tpl_desc'] = 'The chunk for displaying each row.';