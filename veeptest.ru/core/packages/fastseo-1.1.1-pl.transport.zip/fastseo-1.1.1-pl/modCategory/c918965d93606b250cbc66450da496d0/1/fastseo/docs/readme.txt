--------------------
Extra: fastSEO
--------------------
Version: 1.1.1
Since: April 28th, 2015
Author: Vadim Rudnitskiy <griveh@rambler.ru>
Git: https://github.com/griven/fastseo
