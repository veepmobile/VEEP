<?php

$_lang['tagelementplugin_main'] = 'Main';

$_lang['setting_tagelementplugin_quick_editor_keys'] = 'Open the quick editing window';
$_lang['setting_tagelementplugin_quick_editor_keys_desc'] = 'Shortcut for editing elements in the quick editing window. You can specify a digital key code.';
$_lang['setting_tagelementplugin_element_editor_keys'] = "Go to the element's page";
$_lang['setting_tagelementplugin_element_editor_keys_desc'] = "Shortcut to go to the element's page. You can specify a digital key code.";
$_lang['setting_tagelementplugin_element_prop_keys'] = 'Open the "Select element options" window';
$_lang['setting_tagelementplugin_element_prop_keys_desc'] = 'Shortcut to open the "Select element options" window. You can specify a digital key code.';
$_lang['setting_tagelementplugin_quick_chunk_editor_keys'] = 'Open the chunk editing window';
$_lang['setting_tagelementplugin_quick_chunk_editor_keys_desc'] = 'Shortcut to open the selection as a chunk in the quick editing window. You can specify a digital key code.';
$_lang['setting_tagelementplugin_chunk_editor_keys'] = "Go to the chunk update form";
$_lang['setting_tagelementplugin_chunk_editor_keys_desc'] = "Shortcut to go to chunk update form. You can specify a digital key code.";