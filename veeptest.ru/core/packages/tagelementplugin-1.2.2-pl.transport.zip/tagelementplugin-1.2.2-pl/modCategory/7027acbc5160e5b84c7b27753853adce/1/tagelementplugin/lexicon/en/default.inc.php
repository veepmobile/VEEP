<?php
$_lang['save_as'] = 'Save as';
$_lang['copy_of'] = 'Copy of';
$_lang['chunk_err_nf'] = 'Chunk not found! Create a new chunk with this name?';
$_lang['snippet_err_nf'] = 'Snippet not found! Create a new snippet with this name?';
$_lang['chunk_err_ae'] = 'Chunk with that name already exists!';
$_lang['snippet_err_ae'] = 'Snippet with that name already exists!';
$_lang['tagelementplugin_tag_value'] = 'Tag value';
$_lang['tagelementplugin_err_nf'] = 'The tag is not found!';