<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'f5b343f2b8169682bc0bf58937596ac1',
      'native_key' => 'core',
      'filename' => 'modNamespace/ba8870fe0a3236e02f0dda732d720064.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modWorkspace',
      'guid' => 'daf7e89bbf1de95e3607e596b84d009b',
      'native_key' => 1,
      'filename' => 'modWorkspace/fbb49ef494dd5cf62e09cde7ea948b19.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modTransportProvider',
      'guid' => '347dccd8057fd14fd181bde539705d16',
      'native_key' => 1,
      'filename' => 'modTransportProvider/49424a2fdf3a5426f53038271c66c4a8.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '89b54627769450a18148ebd6f41487dd',
      'native_key' => 'topnav',
      'filename' => 'modMenu/3a3f5767c098fb6653b597a3c3c21b32.vehicle',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '3cb5820b07b649dd2a63656c3ed7e15b',
      'native_key' => 'usernav',
      'filename' => 'modMenu/f1d4248069c1a33d9093bf499b5123ab.vehicle',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'fa80edd78cc8832a14ddb010b09d28ed',
      'native_key' => 1,
      'filename' => 'modContentType/71440eff6fd8fd9d5116ce4f2fa5215e.vehicle',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'dca3e99593bdb3d653e928d5ae2b3658',
      'native_key' => 2,
      'filename' => 'modContentType/6baf0f72adb720451ec3a7af1f20b1a9.vehicle',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'a0e73d5aa9519bdce7a1a758d71d0c2b',
      'native_key' => 3,
      'filename' => 'modContentType/67e215f3eebfee331929fd4e04569054.vehicle',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '3202c1ad42149a9591fb829d69d57199',
      'native_key' => 4,
      'filename' => 'modContentType/d02172111816bf7884190e2293afbcca.vehicle',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '403f69fd2d6831d8505f4ae530f2fa35',
      'native_key' => 5,
      'filename' => 'modContentType/77df65eb512c7d15a76e2869149e4a0a.vehicle',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '79cdca46c823fdc7771602cd76c6501f',
      'native_key' => 6,
      'filename' => 'modContentType/ca920489ba26711989853deca2011919.vehicle',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '68473dce84bb4cf5467a225fcb7cedb9',
      'native_key' => 7,
      'filename' => 'modContentType/92b4294e7393f32358f4a53599a467d1.vehicle',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '5aefb038fe77a0e8d3f3c953e7c7bb48',
      'native_key' => 8,
      'filename' => 'modContentType/bef4902d9e65f187396fba2f3c8b0648.vehicle',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '4dba73364dc06924b8e3020f1df317d6',
      'native_key' => NULL,
      'filename' => 'modClassMap/1d4167ccf270d4cfee5320f43c42f7f0.vehicle',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '208b9e0fcf883f4a01cc827aeef973e8',
      'native_key' => NULL,
      'filename' => 'modClassMap/120d879cc6c24764d0e32828eca9f7b4.vehicle',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '33156d8875c005355fb949b121b52f74',
      'native_key' => NULL,
      'filename' => 'modClassMap/571d3258239055f99268524911a32136.vehicle',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '0937d579e22643421d676a44e033a0ff',
      'native_key' => NULL,
      'filename' => 'modClassMap/6d2475c1ff60dfaae01662db3f4e1bba.vehicle',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'c573c13ad84ef0a86b9a80ac3d4853bb',
      'native_key' => NULL,
      'filename' => 'modClassMap/491349300dd3a4f9c2ccd306e4106609.vehicle',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'ae279429985bc4ce941568366d72a65a',
      'native_key' => NULL,
      'filename' => 'modClassMap/ac5aa288956c34cf98c71d67c38b42fc.vehicle',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '51bcc2a6e5040cad60c9b6e6a632696b',
      'native_key' => NULL,
      'filename' => 'modClassMap/02e5870bd657de5bcceb77dbcf150657.vehicle',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'a90b321638bb45fec8713f4c436d1ce1',
      'native_key' => NULL,
      'filename' => 'modClassMap/403b954ddce539ed6fce84411941f0a8.vehicle',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '6fb88c25ffd7f03962f668c0f91a9540',
      'native_key' => NULL,
      'filename' => 'modClassMap/42a25b1457851828c94938662e9f650f.vehicle',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f7d61743417be5161c47308ed865828b',
      'native_key' => 'OnPluginEventBeforeSave',
      'filename' => 'modEvent/ad4d399292f1d7a555dec5e48b87bb0f.vehicle',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '21ac8a6af3655308b06942bdf7a7e52e',
      'native_key' => 'OnPluginEventSave',
      'filename' => 'modEvent/f506ad4068a8cfa3fc1ac75dd259e04b.vehicle',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '11f4c44daab179900dca5fd72a73a80d',
      'native_key' => 'OnPluginEventBeforeRemove',
      'filename' => 'modEvent/68a8d5402c91b91ff24740bdea564d3d.vehicle',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ab8c8ff255ac44738b6b493c11bcc046',
      'native_key' => 'OnPluginEventRemove',
      'filename' => 'modEvent/851c8aeddda4b0f1c0f9a801b5f034e5.vehicle',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7e9912dd8045e5b5fe0e232d961ab292',
      'native_key' => 'OnResourceGroupSave',
      'filename' => 'modEvent/b7acae60b3155ffab5841c0b751a9faf.vehicle',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b341e0a6a33048fd8de075176427a1c0',
      'native_key' => 'OnResourceGroupBeforeSave',
      'filename' => 'modEvent/526d4b6d7f34e49b0d962063735bb723.vehicle',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ede2c7665f9b48942b8255c80e871229',
      'native_key' => 'OnResourceGroupRemove',
      'filename' => 'modEvent/98c347f7b4822b6fca6561c7783678de.vehicle',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0f4ad2a6f749124ba8af864c3dbc8bde',
      'native_key' => 'OnResourceGroupBeforeRemove',
      'filename' => 'modEvent/6172273c2272e2b5a5762d9901f00fee.vehicle',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2ce9378d53858f9702661a914282ea21',
      'native_key' => 'OnSnippetBeforeSave',
      'filename' => 'modEvent/2c6dda5aec385b739c02ece143dc85d5.vehicle',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c2e948b1bccc8f9d14e37b2be1ee277b',
      'native_key' => 'OnSnippetSave',
      'filename' => 'modEvent/888fd706168a5ec5bfeabf09329468c3.vehicle',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2ef3c1fb0394558b9feeef93942e2da3',
      'native_key' => 'OnSnippetBeforeRemove',
      'filename' => 'modEvent/357d54cc4fce14ec40a57fbb504f86e4.vehicle',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd4c1c46e7a737656587aa11356bd491f',
      'native_key' => 'OnSnippetRemove',
      'filename' => 'modEvent/1d9a398d6ef2d71895cd17dc76e187a0.vehicle',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3a7004dac4af8f21347b280dd0a6ec6e',
      'native_key' => 'OnSnipFormPrerender',
      'filename' => 'modEvent/a659b5b8570c5a2935e8cb87a5ee4aac.vehicle',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '50bc85c1ba5eeab493e850f6c15ffbac',
      'native_key' => 'OnSnipFormRender',
      'filename' => 'modEvent/21605f3c6f44512e73b12b663d092e6b.vehicle',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a50baccbd4fb32e005bec13ff5dee57d',
      'native_key' => 'OnBeforeSnipFormSave',
      'filename' => 'modEvent/d1abcb6ae41b13f71e74ed6a976ba85e.vehicle',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bbb61c7ce00095f784f8ff6061c69feb',
      'native_key' => 'OnSnipFormSave',
      'filename' => 'modEvent/bce30350a78a1d21f3b508cc645620ef.vehicle',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4acc70bcc031c31b3f3d0bce924d7ed2',
      'native_key' => 'OnBeforeSnipFormDelete',
      'filename' => 'modEvent/89b62da37405fae9b29af7ef0141be49.vehicle',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '80943dfae54034d1232a195ef14dcf67',
      'native_key' => 'OnSnipFormDelete',
      'filename' => 'modEvent/2612e68431e8d37edf7a3666094aef9b.vehicle',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2770ec98e9272da03629eaadfa063847',
      'native_key' => 'OnTemplateBeforeSave',
      'filename' => 'modEvent/c281a1f4b60bcae965ccbe7058ec7c57.vehicle',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e8da4bd4cc46b04c3ca267261f19b8d9',
      'native_key' => 'OnTemplateSave',
      'filename' => 'modEvent/2eb846cebdb65b653a10590e4dbaf4f4.vehicle',
    ),
    42 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1b0735a374c3c549204d503d5fc73999',
      'native_key' => 'OnTemplateBeforeRemove',
      'filename' => 'modEvent/f24cbb51120d990e6ac1927ee0b1ccef.vehicle',
    ),
    43 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '89377495ae34f993dbea288eea6d4546',
      'native_key' => 'OnTemplateRemove',
      'filename' => 'modEvent/364ceaa53e80672370d7a09241157412.vehicle',
    ),
    44 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '259d8b6a73e9126323330311f9c88452',
      'native_key' => 'OnTempFormPrerender',
      'filename' => 'modEvent/bf8c84efe21ec884efa92b3aca1325c8.vehicle',
    ),
    45 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '90e132b7cb4c90a326ef3bb8e52222fd',
      'native_key' => 'OnTempFormRender',
      'filename' => 'modEvent/ea0fc5d14cfd2cf4eca1e38084c13737.vehicle',
    ),
    46 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '26fe74cf77e1c34c20cbd0f395253bcc',
      'native_key' => 'OnBeforeTempFormSave',
      'filename' => 'modEvent/63163f750942e88354f8dcf69d75cc18.vehicle',
    ),
    47 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cbac2007cbe0c620b530e7486237759b',
      'native_key' => 'OnTempFormSave',
      'filename' => 'modEvent/139cd16c3bd0a56cb097a0f49556f3c4.vehicle',
    ),
    48 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c8c28c568d307c9208ffc765b10c7587',
      'native_key' => 'OnBeforeTempFormDelete',
      'filename' => 'modEvent/ded4e36f15eee4b2b500b5ac6dfd062c.vehicle',
    ),
    49 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e2450e6affee2124b5066225ed8bd592',
      'native_key' => 'OnTempFormDelete',
      'filename' => 'modEvent/92a2fa92f4fe9654bcbfce5818cb243f.vehicle',
    ),
    50 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7278523750783036163d394116f0e323',
      'native_key' => 'OnTemplateVarBeforeSave',
      'filename' => 'modEvent/61532f08d76041df22ece6cabb58a242.vehicle',
    ),
    51 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cca62424cbd7dd94de5609052cbad76b',
      'native_key' => 'OnTemplateVarSave',
      'filename' => 'modEvent/154be06b55dd6e7e022db28b16eaaba7.vehicle',
    ),
    52 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0d0249131a05d13371e773f040412a25',
      'native_key' => 'OnTemplateVarBeforeRemove',
      'filename' => 'modEvent/c41f7f144ccf9cfadbd7e523de8588b2.vehicle',
    ),
    53 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bbec3dbaaf17eae7b245b8b70be031b4',
      'native_key' => 'OnTemplateVarRemove',
      'filename' => 'modEvent/ba84869301fa54810b246f638975861f.vehicle',
    ),
    54 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '216bf5a19b3277cc1df23dbe9da4c7d0',
      'native_key' => 'OnTVFormPrerender',
      'filename' => 'modEvent/fb9e9dbbbe08d3b2131d1137675b7c15.vehicle',
    ),
    55 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4060c821b78541932eef2790409c9a5c',
      'native_key' => 'OnTVFormRender',
      'filename' => 'modEvent/690b88cb06c9817f8e58278fb4b1ffbf.vehicle',
    ),
    56 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f2afe6f86e30c4c3161528dd9cff1a4f',
      'native_key' => 'OnBeforeTVFormSave',
      'filename' => 'modEvent/0bcecdc20b52c28b2558acde1a8d7679.vehicle',
    ),
    57 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c3d0837a13595437f480a9cb14c9940f',
      'native_key' => 'OnTVFormSave',
      'filename' => 'modEvent/9e65dd2787c605c85a6afcb9d4199c17.vehicle',
    ),
    58 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '93d0f1d44e7eec3fdb910e46dbce8a1e',
      'native_key' => 'OnBeforeTVFormDelete',
      'filename' => 'modEvent/a9692992fa184e3b5c8b2578265bb20c.vehicle',
    ),
    59 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '36c1b5de36da781c063a28403c9f74e9',
      'native_key' => 'OnTVFormDelete',
      'filename' => 'modEvent/2a8eae354255650d464dd1047d8c08f9.vehicle',
    ),
    60 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '41266e78e9a6e0578c242427542ddd24',
      'native_key' => 'OnTVInputRenderList',
      'filename' => 'modEvent/841b26bc3eab59d853434d6d13b1b673.vehicle',
    ),
    61 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '630157143fc2c1af90522e30b8c80658',
      'native_key' => 'OnTVInputPropertiesList',
      'filename' => 'modEvent/2787e735fff1cfdccdc52e8cc0183721.vehicle',
    ),
    62 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b27b20bc4251f0e8edc3c27fec8785aa',
      'native_key' => 'OnTVOutputRenderList',
      'filename' => 'modEvent/3e285e6e958d6e77eef6eba81dad8f41.vehicle',
    ),
    63 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fe5a2cb22e6f1ffb29d517e3bfcc23a8',
      'native_key' => 'OnTVOutputRenderPropertiesList',
      'filename' => 'modEvent/dbdc5f34ac17822b3b4957413812ea7d.vehicle',
    ),
    64 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '26979c1dafdca0fd98499cb98f94a049',
      'native_key' => 'OnUserGroupBeforeSave',
      'filename' => 'modEvent/4d15bc2cd53dd8e01e86fd364cef06af.vehicle',
    ),
    65 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b126a849cd230ab485e7ed781ec7987c',
      'native_key' => 'OnUserGroupSave',
      'filename' => 'modEvent/651d1a35bdfdfae0bc559d3018a3821f.vehicle',
    ),
    66 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '02c82106c90b36c42eaaf300ecc2c868',
      'native_key' => 'OnUserGroupBeforeRemove',
      'filename' => 'modEvent/c27da4bdd68690ddf74540fee0de0421.vehicle',
    ),
    67 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '634e14b81fb945a77101d9ad24411ffd',
      'native_key' => 'OnUserGroupRemove',
      'filename' => 'modEvent/c6b3d65e7c51abcc5e25a9cb9d09a8e6.vehicle',
    ),
    68 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fbf50c8e6134feabd8b1b68b1a7d2af5',
      'native_key' => 'OnBeforeUserGroupFormSave',
      'filename' => 'modEvent/157a1773a63b1cde265d2a463842f5a6.vehicle',
    ),
    69 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8146307d634b6e2342b9573194210302',
      'native_key' => 'OnUserGroupFormSave',
      'filename' => 'modEvent/62a2957b4b61fea892f439a4cbf5d713.vehicle',
    ),
    70 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '55da63c706dfd6696988e05a024d6d99',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/865c475f93a543577ffb7ba1b5652f50.vehicle',
    ),
    71 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ecb82a76077ff33fc58278d426ec3fe3',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/71bc6c8a87948c9dba1f798a103a06ae.vehicle',
    ),
    72 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cbf962b7d7af8523f43010bcc8a6e6ef',
      'native_key' => 'OnDocFormPrerender',
      'filename' => 'modEvent/df0d0f07c2ca883dce4733c2c3e95669.vehicle',
    ),
    73 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b1f10a2caf5b9d848d2d83591046e400',
      'native_key' => 'OnDocFormRender',
      'filename' => 'modEvent/3134752ced99993c63f00e29ae327511.vehicle',
    ),
    74 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c60d948c55d8d42605664b325a91ea15',
      'native_key' => 'OnBeforeDocFormSave',
      'filename' => 'modEvent/ab7dac84e1adf6ab4b80a1fb93c85637.vehicle',
    ),
    75 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c3138f246a0c1f42c90a4b65766b68de',
      'native_key' => 'OnDocFormSave',
      'filename' => 'modEvent/baf06e2fa499b645edca02a523952f5d.vehicle',
    ),
    76 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9c3fd3e82486052ab149f9f466e754ad',
      'native_key' => 'OnBeforeDocFormDelete',
      'filename' => 'modEvent/fb7672e1bfa6d4b966a0369f2f2c952d.vehicle',
    ),
    77 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4ea67634ed3ab23a20672e433b7f2f5c',
      'native_key' => 'OnDocFormDelete',
      'filename' => 'modEvent/223e4f0e5b688f4537f74066febffff3.vehicle',
    ),
    78 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e84a3d513f58f36ecf8ccc2c58afcef3',
      'native_key' => 'OnDocPublished',
      'filename' => 'modEvent/c8487ce044918ec8d318547c9be11d36.vehicle',
    ),
    79 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ea887d4b1489e3125b93c2c81ea598a1',
      'native_key' => 'OnDocUnPublished',
      'filename' => 'modEvent/7db15e65fe5ce6eccf6861c319da295c.vehicle',
    ),
    80 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '299c9a10178d4e88d17bd535dac34bc1',
      'native_key' => 'OnBeforeEmptyTrash',
      'filename' => 'modEvent/f921ef227e1ab6a88d345ae5cda11f70.vehicle',
    ),
    81 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ac90054015acf4b58db8bfd540ad8da7',
      'native_key' => 'OnEmptyTrash',
      'filename' => 'modEvent/13ab44ac3299cf2fe2b9d10b66f4f8e0.vehicle',
    ),
    82 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'da669efe293249693b7862f344109b7d',
      'native_key' => 'OnResourceTVFormPrerender',
      'filename' => 'modEvent/b35967556b7f37fda65c5b8f5b1c2645.vehicle',
    ),
    83 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '11e1c939d57410860cbec477906b125c',
      'native_key' => 'OnResourceTVFormRender',
      'filename' => 'modEvent/d43e4f79478d42cf5b63cd04bb4ad6ce.vehicle',
    ),
    84 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2350feafd4e748d4d394507aefda96a0',
      'native_key' => 'OnResourceAutoPublish',
      'filename' => 'modEvent/589a23a1ac02f04a9f273c85aedd2644.vehicle',
    ),
    85 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd5820cfe80a6a006cdeb30f54cbc0986',
      'native_key' => 'OnResourceDelete',
      'filename' => 'modEvent/1036b4b594244d4c35375c8f45803d6c.vehicle',
    ),
    86 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'aa0a9a235c4d72c786aa62d5b56503ef',
      'native_key' => 'OnResourceUndelete',
      'filename' => 'modEvent/946c56f89939b2ed5eac0a3c0b7e62ca.vehicle',
    ),
    87 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2ff0863c6b9a780e5df316402640438f',
      'native_key' => 'OnResourceBeforeSort',
      'filename' => 'modEvent/4df923e4832cd6cdd7cd4a5735ca4587.vehicle',
    ),
    88 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2b027ba8e8b2499d6be1a4a8b7b91160',
      'native_key' => 'OnResourceSort',
      'filename' => 'modEvent/8e864ed18cc9cbd7f257f10472f4411d.vehicle',
    ),
    89 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b6fbebfeef7f8767d0f8ba2108f9a587',
      'native_key' => 'OnResourceDuplicate',
      'filename' => 'modEvent/fcd7ca0c0510300a4c924c342142bee0.vehicle',
    ),
    90 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd2a4dc62e461ec044471f2759f532955',
      'native_key' => 'OnResourceToolbarLoad',
      'filename' => 'modEvent/b6884337491f8debb937415196d2bb76.vehicle',
    ),
    91 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ac1369a82cd1e3bae95a89bf643a4574',
      'native_key' => 'OnResourceRemoveFromResourceGroup',
      'filename' => 'modEvent/956564ed6ab10da5b76434502fabe03d.vehicle',
    ),
    92 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '634d1475763ac87d1199dbc37f040826',
      'native_key' => 'OnResourceAddToResourceGroup',
      'filename' => 'modEvent/72aaa2434deba36f9bca1ccb841ce485.vehicle',
    ),
    93 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c204c4f9aec8928829c043ee42036d0c',
      'native_key' => 'OnRichTextEditorRegister',
      'filename' => 'modEvent/c32ffc0c726ce26a4faa1f88ef4c7590.vehicle',
    ),
    94 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '88be68d7fb572acb9a648b668f165d5e',
      'native_key' => 'OnRichTextEditorInit',
      'filename' => 'modEvent/b267be52cfd2e8e032a757a2cfb0cf3f.vehicle',
    ),
    95 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cf3ffcb60c7d6149e4713ed38f4dccec',
      'native_key' => 'OnRichTextBrowserInit',
      'filename' => 'modEvent/dde39a5b4f9a0bd1fce73d6db4a317df.vehicle',
    ),
    96 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f53335beaecefc9556c33d9d31b911f6',
      'native_key' => 'OnWebLogin',
      'filename' => 'modEvent/f671e1e3b69a6c4ab9bfa528e90e4d8e.vehicle',
    ),
    97 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2dd926de868beb1ee7102c45b19d7cc9',
      'native_key' => 'OnBeforeWebLogout',
      'filename' => 'modEvent/c989473012c4851a3bd222a0d55c2e38.vehicle',
    ),
    98 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '036878a56fb0210f1d15baae2724cfc8',
      'native_key' => 'OnWebLogout',
      'filename' => 'modEvent/07db6dbd69bfde61addc07bd136e9fcf.vehicle',
    ),
    99 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0fb08c5f0d314261d8ab9ccd740b7ba4',
      'native_key' => 'OnManagerLogin',
      'filename' => 'modEvent/4cf78920a375c759167e0781912a9629.vehicle',
    ),
    100 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e53f212f8b8d50cddb14ee51316912d6',
      'native_key' => 'OnBeforeManagerLogout',
      'filename' => 'modEvent/444bc850d5020bb5c3d629627514e865.vehicle',
    ),
    101 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '73d1460377bd94c17b3ab43f346a5d36',
      'native_key' => 'OnManagerLogout',
      'filename' => 'modEvent/ec9abf0ff605102b105ef66409c68afa.vehicle',
    ),
    102 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd34a0375cf8cdbfd4734371729969abf',
      'native_key' => 'OnBeforeWebLogin',
      'filename' => 'modEvent/63bbf898245d7ca0aadb34bd2442847f.vehicle',
    ),
    103 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a06bc0445dc77fd6eda74a1cc9bfc7ae',
      'native_key' => 'OnWebAuthentication',
      'filename' => 'modEvent/18d79e0aa40578505308a855ffc75da6.vehicle',
    ),
    104 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1a6c210e2126c662a0c189b860362a30',
      'native_key' => 'OnBeforeManagerLogin',
      'filename' => 'modEvent/7b5d7951ada7a45837d19025e889010a.vehicle',
    ),
    105 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2a897c7e2570774bf8e041a815dfbfac',
      'native_key' => 'OnManagerAuthentication',
      'filename' => 'modEvent/2e1192b99ee2545a1ad8ca5dc58e1032.vehicle',
    ),
    106 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '610e6b7cbab1d14c663d794acbcd3f15',
      'native_key' => 'OnManagerLoginFormRender',
      'filename' => 'modEvent/767e1c3187ea75d2820ef4a571a848c3.vehicle',
    ),
    107 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'edd1d882b300e2c823a9855703ebeee7',
      'native_key' => 'OnManagerLoginFormPrerender',
      'filename' => 'modEvent/10cff7eca5e02e1715476dc8ee298ca8.vehicle',
    ),
    108 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2ade812288ee247b646677b67738211e',
      'native_key' => 'OnPageUnauthorized',
      'filename' => 'modEvent/a6a255ea1bda6e9520c670271b465273.vehicle',
    ),
    109 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b870d88dde5505a105bdd29bdaf113c7',
      'native_key' => 'OnUserFormPrerender',
      'filename' => 'modEvent/572c7b2c6652844b46e53476f8fcb36a.vehicle',
    ),
    110 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0c8308b4f9cf525af1665a8e7dd413e2',
      'native_key' => 'OnUserFormRender',
      'filename' => 'modEvent/c4d44a45dd40f646ddb04e58de359af0.vehicle',
    ),
    111 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dbd7622989f1e284d5cb14909342f77a',
      'native_key' => 'OnBeforeUserFormSave',
      'filename' => 'modEvent/d16f131268e1ce3cf75eaaca18778f9d.vehicle',
    ),
    112 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '984fb9c8896468dcff6824efbd41412c',
      'native_key' => 'OnUserFormSave',
      'filename' => 'modEvent/906c7092c1238db2e012055b5e39a07d.vehicle',
    ),
    113 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9b77db25485e9e33439e52858df72b97',
      'native_key' => 'OnBeforeUserFormDelete',
      'filename' => 'modEvent/d2eb1f08949271cb33f1eda083c456aa.vehicle',
    ),
    114 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5c954ae9614c71091faa76889408c06c',
      'native_key' => 'OnUserFormDelete',
      'filename' => 'modEvent/110c0df07b2acc660b6f64df2bc93e5c.vehicle',
    ),
    115 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5c193a642e9dc9e4fcb6b597879997da',
      'native_key' => 'OnUserNotFound',
      'filename' => 'modEvent/f50cac135b4fb7c2aa0a4c7df525e97b.vehicle',
    ),
    116 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a51d8b0a48c2761a6ac1612c01b12e0c',
      'native_key' => 'OnBeforeUserActivate',
      'filename' => 'modEvent/19ad192bfca92324168557eef1b5a4e1.vehicle',
    ),
    117 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e931fe87cedb722634c02cb15b6690ae',
      'native_key' => 'OnUserActivate',
      'filename' => 'modEvent/fc9cedae6f08b1cc2ad2c73c00615b27.vehicle',
    ),
    118 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4cfcf8f577beedae34e6bf76e42b100c',
      'native_key' => 'OnBeforeUserDeactivate',
      'filename' => 'modEvent/77960d066dbb7c6eaba351143b4956fd.vehicle',
    ),
    119 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '01f129cd08a33e64e9fcccb007163581',
      'native_key' => 'OnUserDeactivate',
      'filename' => 'modEvent/b80fe5f6b6629bdfc03649960891a7be.vehicle',
    ),
    120 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '335bb9ae0ef75584570a31ffbd685e9b',
      'native_key' => 'OnBeforeUserDuplicate',
      'filename' => 'modEvent/4cba3b0eca144a345bd129c200fd40e6.vehicle',
    ),
    121 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a2526cecc6f10a7e7e24aace956cca1f',
      'native_key' => 'OnUserDuplicate',
      'filename' => 'modEvent/55d28d5d8c5402be8c87ddd7729c74c8.vehicle',
    ),
    122 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5d5ed8fabde5ac8d7abe338ed1862220',
      'native_key' => 'OnUserChangePassword',
      'filename' => 'modEvent/d89b085bb0fc4750b7f7cbdf01b82293.vehicle',
    ),
    123 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bf26859212ba74e4e608bb6ff66f9f40',
      'native_key' => 'OnUserBeforeRemove',
      'filename' => 'modEvent/5b7a17833e67ad8bba87fcbc3ecdad84.vehicle',
    ),
    124 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4b04cdd029eb97052e8462f14a334d1b',
      'native_key' => 'OnUserBeforeSave',
      'filename' => 'modEvent/fd3dd4d5b8347fac073f44d827f4535c.vehicle',
    ),
    125 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '157b6eedcd34eb92583b1a563ca54f19',
      'native_key' => 'OnUserSave',
      'filename' => 'modEvent/fc97d4773f18cd9a2fc216647055ce5e.vehicle',
    ),
    126 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1893d6a364a53032e86d13200815b93c',
      'native_key' => 'OnUserRemove',
      'filename' => 'modEvent/56c68e615ec6a093ede1b54f716f4e3e.vehicle',
    ),
    127 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bdb4aa3606e9492a5a80b3304dfbffff',
      'native_key' => 'OnUserBeforeAddToGroup',
      'filename' => 'modEvent/d51600900ede9cf0a1f4eea08ea914d3.vehicle',
    ),
    128 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f92d3db26484a2eebc6d1e63deb033ae',
      'native_key' => 'OnUserAddToGroup',
      'filename' => 'modEvent/2e948ce82dc9d999f8802ebd6f1e1072.vehicle',
    ),
    129 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9e8e3204e2a70fe7130264a6b379d3c5',
      'native_key' => 'OnUserBeforeRemoveFromGroup',
      'filename' => 'modEvent/0b68f48db22307d3079449166c4b64b6.vehicle',
    ),
    130 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bb84116b72a130778c6c0ccd79c1d8d5',
      'native_key' => 'OnUserRemoveFromGroup',
      'filename' => 'modEvent/14999d19723ad0f61d0bd6f479efffc9.vehicle',
    ),
    131 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'afb726c328be07c0c294d29d1f91c78b',
      'native_key' => 'OnWebPagePrerender',
      'filename' => 'modEvent/494614f9398dae587c98e706397c4a16.vehicle',
    ),
    132 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8ce8319b81aac9cd6e744b14f2d0e01d',
      'native_key' => 'OnBeforeCacheUpdate',
      'filename' => 'modEvent/4f6c67f600bed3778ef40248ed9c833f.vehicle',
    ),
    133 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'caa708ed82e745784dec252bd339ce8d',
      'native_key' => 'OnCacheUpdate',
      'filename' => 'modEvent/a3fa31f28011e3515e3ef1b80fc16738.vehicle',
    ),
    134 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c0ab34c130610ef2caa819992978392c',
      'native_key' => 'OnLoadWebPageCache',
      'filename' => 'modEvent/49156465d210323ebccc5f430d76967f.vehicle',
    ),
    135 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0abeb3f600e204a392bea15778fb8bf3',
      'native_key' => 'OnBeforeSaveWebPageCache',
      'filename' => 'modEvent/2fe31ca817231647febbc38738f215cb.vehicle',
    ),
    136 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'be85c681044e4361f4d94d1da168cdef',
      'native_key' => 'OnSiteRefresh',
      'filename' => 'modEvent/b129d1036fd7599db978b5ad375d15a8.vehicle',
    ),
    137 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd73fc743808ec62fda33e029609b645f',
      'native_key' => 'OnFileManagerDirCreate',
      'filename' => 'modEvent/d1dff5b5761a44e4b9c89b83004080d3.vehicle',
    ),
    138 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2eeb016f7b44a67bdf082c5d65aacd0b',
      'native_key' => 'OnFileManagerDirRemove',
      'filename' => 'modEvent/dfff20b269e9e1edb060261ea1376e8e.vehicle',
    ),
    139 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c8764c5fa0f8e4a1ad3702d2f395a386',
      'native_key' => 'OnFileManagerDirRename',
      'filename' => 'modEvent/75bf751614d0f991be5e95e8ef57d7ce.vehicle',
    ),
    140 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3cff1bdb7c7b5fd99056050decedec59',
      'native_key' => 'OnFileManagerFileRename',
      'filename' => 'modEvent/6a17b2097fbb7494845e4b396211591d.vehicle',
    ),
    141 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '21c7117f773c67732341382464846c9e',
      'native_key' => 'OnFileManagerFileRemove',
      'filename' => 'modEvent/c3fe68fd78488e50cac4971dfa322fb1.vehicle',
    ),
    142 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5611b85022a391bbe942925dee68a625',
      'native_key' => 'OnFileManagerFileUpdate',
      'filename' => 'modEvent/06a5c218b3e2b597d0b1a29ad0670afa.vehicle',
    ),
    143 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9a68ce847ca4beba709bdc9bddeb68cb',
      'native_key' => 'OnFileManagerFileCreate',
      'filename' => 'modEvent/04b2d6fda5b1ee68aaa2ad3d16452bd0.vehicle',
    ),
    144 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e55d3f6ba11a7cdc80a2d4f0a8d8bf9f',
      'native_key' => 'OnFileManagerBeforeUpload',
      'filename' => 'modEvent/a993d4fc2e3b210c1aae73b12bae0d3a.vehicle',
    ),
    145 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '93a9f6291c3f70e479484255cbfb4881',
      'native_key' => 'OnFileManagerUpload',
      'filename' => 'modEvent/37db9c0ef93c03a73f167b90bba8e76e.vehicle',
    ),
    146 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e650a91c7f15ffc8f356103d78b7a6ad',
      'native_key' => 'OnFileManagerMoveObject',
      'filename' => 'modEvent/89ba1a3bea00f3fe3c06d6211bf7248e.vehicle',
    ),
    147 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5d900b21a78cb91f8adc237287b509ab',
      'native_key' => 'OnFileCreateFormPrerender',
      'filename' => 'modEvent/2d1817cb63dafe272a281b9bae10a41e.vehicle',
    ),
    148 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'db638b34d2a8a281e2089c1b2ccfb226',
      'native_key' => 'OnFileEditFormPrerender',
      'filename' => 'modEvent/aea1c038771fd12ece773abc695b1a37.vehicle',
    ),
    149 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '81b75b6dd2659c1c6a9e3101676ac24e',
      'native_key' => 'OnManagerPageInit',
      'filename' => 'modEvent/066604e41296dfca19ff8132021bfc01.vehicle',
    ),
    150 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3cceb1b1e9d0851366f80a2179d54efb',
      'native_key' => 'OnManagerPageBeforeRender',
      'filename' => 'modEvent/f62c7a72544c1ff19725a8d52170092a.vehicle',
    ),
    151 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8f61ae2b563d62fd154b9a6d8af89da8',
      'native_key' => 'OnManagerPageAfterRender',
      'filename' => 'modEvent/4532ebbafbe39b3c6cccac0add65f93e.vehicle',
    ),
    152 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'af4fe6a23ef1e60c6bb53db5b350e4f0',
      'native_key' => 'OnWebPageInit',
      'filename' => 'modEvent/c8a0e751896f686ed88103e66db11b1d.vehicle',
    ),
    153 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '03dbf79703e858578bb0708483412bd8',
      'native_key' => 'OnLoadWebDocument',
      'filename' => 'modEvent/263113f20689e7dd440a95ceca55650d.vehicle',
    ),
    154 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '33b8d9642d86d67b7125775ffb4c0345',
      'native_key' => 'OnParseDocument',
      'filename' => 'modEvent/850b94df1667b881b502d408995804c0.vehicle',
    ),
    155 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cda63b481484e2a76061169f9713c409',
      'native_key' => 'OnWebPageComplete',
      'filename' => 'modEvent/35f0b23a0b7596ed6c6385374e987ed1.vehicle',
    ),
    156 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '619de51304b016325befa6a1f84be96f',
      'native_key' => 'OnBeforeManagerPageInit',
      'filename' => 'modEvent/dfc9b996191ebf4209a54455ae3eabb9.vehicle',
    ),
    157 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f489000f567e0e6d6bf4c00ea7ccd922',
      'native_key' => 'OnPageNotFound',
      'filename' => 'modEvent/7166668cf1a3b8b22c78ea8396b9c4aa.vehicle',
    ),
    158 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2285a1b93ebebf4f5459092af69cf28f',
      'native_key' => 'OnHandleRequest',
      'filename' => 'modEvent/6060d5ae94c7eb21b2f3542c340455c8.vehicle',
    ),
    159 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '64d72022bf388323432c9b098a7a6498',
      'native_key' => 'OnMODXInit',
      'filename' => 'modEvent/71aa5e0e1ebc06d52a4e2ade1b7b1e95.vehicle',
    ),
    160 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '97e5e3b8a0116c681cc12cd35f07dc05',
      'native_key' => 'OnElementNotFound',
      'filename' => 'modEvent/96d971e8dee1b8b27e52037713423ae8.vehicle',
    ),
    161 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8450f9b1a432b4a1d836b85b9a5d03c2',
      'native_key' => 'OnSiteSettingsRender',
      'filename' => 'modEvent/709e893e921925a0a24e852673175e01.vehicle',
    ),
    162 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3a19d46fb8c8d5e49c577165c6fcbaa6',
      'native_key' => 'OnInitCulture',
      'filename' => 'modEvent/141293f90cfbc679ba738f61626bbc2b.vehicle',
    ),
    163 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5af4d661a07b9d89c3b005b28a2a4f28',
      'native_key' => 'OnCategorySave',
      'filename' => 'modEvent/dd46b993a4416e1b2e89273db0ec2692.vehicle',
    ),
    164 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cb24423546279f4ee76dc24a4d78efe1',
      'native_key' => 'OnCategoryBeforeSave',
      'filename' => 'modEvent/599d1b8bf217d51564f7e2c7e7277b18.vehicle',
    ),
    165 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '720a71061f8d8c46d1965b9c0a2c1963',
      'native_key' => 'OnCategoryRemove',
      'filename' => 'modEvent/c43c31237ffc17f360b832da9d801d92.vehicle',
    ),
    166 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '621a9f128f3b3c80fc27f96c3f390689',
      'native_key' => 'OnCategoryBeforeRemove',
      'filename' => 'modEvent/fea5de841e79557743468cd5b6df7469.vehicle',
    ),
    167 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '88cbb9fd23960a7fff5a294eb823e2c6',
      'native_key' => 'OnChunkSave',
      'filename' => 'modEvent/010d126cad448a0bbd0ae891bd9f3656.vehicle',
    ),
    168 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '295642cffc7d1bc79a09024d4c32579f',
      'native_key' => 'OnChunkBeforeSave',
      'filename' => 'modEvent/4535a8c4cb10ca609853de08083f824d.vehicle',
    ),
    169 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f8fee15adc2fdc216c520f24af8a6c17',
      'native_key' => 'OnChunkRemove',
      'filename' => 'modEvent/acb4b61083af4f30a06576b36d13aec1.vehicle',
    ),
    170 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '071cd5cc33bb7db3dea2003b6ef506f3',
      'native_key' => 'OnChunkBeforeRemove',
      'filename' => 'modEvent/5efc70c9a763de55b479da46e9677578.vehicle',
    ),
    171 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3a808d2ffc007c30c1bebe52d3650623',
      'native_key' => 'OnChunkFormPrerender',
      'filename' => 'modEvent/4b083a88a14309ce9e52b2cd7c94c0ab.vehicle',
    ),
    172 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9031e08c01fa3bfcae2cf4d0413e4f0a',
      'native_key' => 'OnChunkFormRender',
      'filename' => 'modEvent/9b7e3fa2baef1c5331a26c9d2ef89420.vehicle',
    ),
    173 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6fb0dc859feee5d00be2756e223b25a7',
      'native_key' => 'OnBeforeChunkFormSave',
      'filename' => 'modEvent/bc75513f5724ba5110b09f176c145a5d.vehicle',
    ),
    174 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e895d2012c4050135abc6857084cb030',
      'native_key' => 'OnChunkFormSave',
      'filename' => 'modEvent/96ead934f99a918e7a2ba34c0d1b50c8.vehicle',
    ),
    175 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '23141ee989ebfded308ddc6e4cfd9f20',
      'native_key' => 'OnBeforeChunkFormDelete',
      'filename' => 'modEvent/12167dcf999dc0b3086fd0c3f25adc30.vehicle',
    ),
    176 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a926d6b264b8a9a70ced4cf976eb2d3c',
      'native_key' => 'OnChunkFormDelete',
      'filename' => 'modEvent/220ee5e9eec0bee2bb00923f8aaa7bd4.vehicle',
    ),
    177 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '53de39fe71830118d943aebb3d54a44d',
      'native_key' => 'OnContextSave',
      'filename' => 'modEvent/bc795b6451ba8e66de48ffc4641a0471.vehicle',
    ),
    178 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4af75c227c83034bb57e2142d4bcfc93',
      'native_key' => 'OnContextBeforeSave',
      'filename' => 'modEvent/1924f0857141a058bcf1f3c0031d1fd1.vehicle',
    ),
    179 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6dc5e676c8f8996813b6106f5ee8bf52',
      'native_key' => 'OnContextRemove',
      'filename' => 'modEvent/79bd7a42f6567c31bf714701c6cf0f99.vehicle',
    ),
    180 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2e47afeb713fcb9a63092b027891de03',
      'native_key' => 'OnContextBeforeRemove',
      'filename' => 'modEvent/87e5a30053173823737699dbbea510ad.vehicle',
    ),
    181 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3200631fc81f2d96c42570ad4459058a',
      'native_key' => 'OnContextFormPrerender',
      'filename' => 'modEvent/44ea1bac5d9dd33ac5f5550f196acdf5.vehicle',
    ),
    182 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '024e31334a2fc53d09142116ac863b66',
      'native_key' => 'OnContextFormRender',
      'filename' => 'modEvent/c840708e263de74bb49dec151bc9f0a4.vehicle',
    ),
    183 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8ff228607402fd82d83d1b4f1ebe32b1',
      'native_key' => 'OnPluginSave',
      'filename' => 'modEvent/104bcd8141b65c194691b67019f2b720.vehicle',
    ),
    184 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5e7ae29e734c208f56fbd376815fd85c',
      'native_key' => 'OnPluginBeforeSave',
      'filename' => 'modEvent/7d7d0505585970f0e59368136fc26ca0.vehicle',
    ),
    185 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b13e357c6c530ba9a7f149ec505530dc',
      'native_key' => 'OnPluginRemove',
      'filename' => 'modEvent/c5564be991ac0602e16aff4edc16a1a1.vehicle',
    ),
    186 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '07caa78433ce1dc469118406547fbddf',
      'native_key' => 'OnPluginBeforeRemove',
      'filename' => 'modEvent/c12fa3fd5674a83e65a30b80111a503d.vehicle',
    ),
    187 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7953997186dd4b70bfbf2d02b391c7c4',
      'native_key' => 'OnPluginFormPrerender',
      'filename' => 'modEvent/e02859d90dea4e890a3895bb1c80e83b.vehicle',
    ),
    188 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '74ea56432dc76344b2a1906517a378cd',
      'native_key' => 'OnPluginFormRender',
      'filename' => 'modEvent/4eceea6d0bc9d986a5ee12d09132dae9.vehicle',
    ),
    189 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '889c15061b274bd1f218223f706f7a64',
      'native_key' => 'OnBeforePluginFormSave',
      'filename' => 'modEvent/b335ecb3b1ce69426f6f91f92a3ecfa0.vehicle',
    ),
    190 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '544fb64dec5b7c2f1722d78a9a907cf0',
      'native_key' => 'OnPluginFormSave',
      'filename' => 'modEvent/6b63ff45b3a3b1592037cfdc73b4c86c.vehicle',
    ),
    191 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '78e222859d9517dd983b1b4a9dd13b08',
      'native_key' => 'OnBeforePluginFormDelete',
      'filename' => 'modEvent/094cc2a86ef10934017c13d94e8afca9.vehicle',
    ),
    192 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '536acf2d56a806221363f3834fdf5ec3',
      'native_key' => 'OnPluginFormDelete',
      'filename' => 'modEvent/f28d65c71593540fc40debf1d182bd16.vehicle',
    ),
    193 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0310351460ac9d125af90246013aa323',
      'native_key' => 'OnPropertySetSave',
      'filename' => 'modEvent/7761e40a14f15e3e05b9df700afc9a72.vehicle',
    ),
    194 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e0c3933a6c8a19b00d2c31ea581ffa1d',
      'native_key' => 'OnPropertySetBeforeSave',
      'filename' => 'modEvent/0a93bddad33dd30f107ec80b957f2618.vehicle',
    ),
    195 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ffd685017ff03c7510245ee6083f427c',
      'native_key' => 'OnPropertySetRemove',
      'filename' => 'modEvent/99556bab845432f93c55e2e21138ac3a.vehicle',
    ),
    196 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0c125c8e7e08a477105a0f0aeaa88076',
      'native_key' => 'OnPropertySetBeforeRemove',
      'filename' => 'modEvent/c466913c70f42aa2ba141d469080d9fa.vehicle',
    ),
    197 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b55f9e7dc6a147539eb0fe10fa84167d',
      'native_key' => 'OnMediaSourceBeforeFormDelete',
      'filename' => 'modEvent/9d468646a03700c553594790ac2357fa.vehicle',
    ),
    198 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'eb961aa32624a9e4876bdb02cc5d436f',
      'native_key' => 'OnMediaSourceBeforeFormSave',
      'filename' => 'modEvent/06a4ef0e44943ca6b539bcce8cafe165.vehicle',
    ),
    199 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a6101ffb9761cdd6f8b0f6139c6f4f8a',
      'native_key' => 'OnMediaSourceGetProperties',
      'filename' => 'modEvent/fa8b6581a78c42f11b1f90c6b39a344c.vehicle',
    ),
    200 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '27624aa41f44a78e77b282f5878f9fd1',
      'native_key' => 'OnMediaSourceFormDelete',
      'filename' => 'modEvent/b045b5515431942ca446263d82d994e9.vehicle',
    ),
    201 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c4b9f6f6b8c34b533349ea7471adb310',
      'native_key' => 'OnMediaSourceFormSave',
      'filename' => 'modEvent/d37ee87c3da1cb17213fdbd71d362178.vehicle',
    ),
    202 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'adf5059ba76a52eee849d986147b945f',
      'native_key' => 'OnMediaSourceDuplicate',
      'filename' => 'modEvent/a45e0bc178d743691f4775df39d04781.vehicle',
    ),
    203 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a88ec1dc5cb4108df7229bdea6eb17dd',
      'native_key' => 'access_category_enabled',
      'filename' => 'modSystemSetting/6edb4aae7c9b56927fe61878d1f82474.vehicle',
    ),
    204 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '921913ae7c7cdab5f8805216ce1284e9',
      'native_key' => 'access_context_enabled',
      'filename' => 'modSystemSetting/46b2cb57d4fcfa3e553158099f1613ed.vehicle',
    ),
    205 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2adb27a172600295e2d722c5ad75e92a',
      'native_key' => 'access_resource_group_enabled',
      'filename' => 'modSystemSetting/098b4e10b4e0ced612b20ff21f10f25b.vehicle',
    ),
    206 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b221eaf01477437617c33d49fdd0985b',
      'native_key' => 'allow_forward_across_contexts',
      'filename' => 'modSystemSetting/cc8eaeb95277e2c23b0373986add46bb.vehicle',
    ),
    207 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '714db30c178884287f01c6e3aca9c366',
      'native_key' => 'allow_manager_login_forgot_password',
      'filename' => 'modSystemSetting/a814f999f3f161ccd9e651caea8146d9.vehicle',
    ),
    208 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'be938ed96b1c6facdb4dd139e923cfeb',
      'native_key' => 'allow_multiple_emails',
      'filename' => 'modSystemSetting/ad510f098a2692cfc3af828840ba8ab3.vehicle',
    ),
    209 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0cb7030c6671cdf35135c700a1b70b9b',
      'native_key' => 'allow_tags_in_post',
      'filename' => 'modSystemSetting/f3ff847db385f295c53825c12cbbcb07.vehicle',
    ),
    210 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '440919658d145c56c32a22c2fb01601f',
      'native_key' => 'archive_with',
      'filename' => 'modSystemSetting/1c1edcbb3b9a7d7b31b689375f39b947.vehicle',
    ),
    211 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '88a623e58cd023ab25f66be78c44af71',
      'native_key' => 'auto_menuindex',
      'filename' => 'modSystemSetting/ff192437b95aeb1e77cf256aadc38e4f.vehicle',
    ),
    212 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2cc727660f6a8165521cfbf6e2cd3877',
      'native_key' => 'auto_check_pkg_updates',
      'filename' => 'modSystemSetting/07ebdfcdfa8c9ff91005210f04ff1088.vehicle',
    ),
    213 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6d4b9c0c1e0625f2db526ffa69ad2b18',
      'native_key' => 'auto_check_pkg_updates_cache_expire',
      'filename' => 'modSystemSetting/3573c2249e2e7a3274dfbadca7969026.vehicle',
    ),
    214 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ffabd410a9c462275ea1fd9317e9416b',
      'native_key' => 'automatic_alias',
      'filename' => 'modSystemSetting/8304df95342f829bdc53078bf69f3a5f.vehicle',
    ),
    215 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd0970034bfbb7e47fcd54ac20c2fee6d',
      'native_key' => 'base_help_url',
      'filename' => 'modSystemSetting/fbb2f3912f30bb4ce6c02d336d29f9ab.vehicle',
    ),
    216 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd90e14aaced4511bfaa72b9af3c81de4',
      'native_key' => 'blocked_minutes',
      'filename' => 'modSystemSetting/3d03c8345321ff248a7886440f14c44d.vehicle',
    ),
    217 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7aaae2a9fbc03f5d8877423b797b372d',
      'native_key' => 'cache_action_map',
      'filename' => 'modSystemSetting/81f784c7d1b1379e464692c9417a1ea9.vehicle',
    ),
    218 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7cfc4aea1d121efdb2edacf961a6b12e',
      'native_key' => 'cache_alias_map',
      'filename' => 'modSystemSetting/4c3baf0636e32bef3243f44268c25b17.vehicle',
    ),
    219 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ff6147b1b84f26df95d2d3ca2c1e0caf',
      'native_key' => 'cache_context_settings',
      'filename' => 'modSystemSetting/8b2eab1f78d4478dca3542229aa8b42b.vehicle',
    ),
    220 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7dbbcba2e81bc38efb96ccb97a1c2708',
      'native_key' => 'cache_db',
      'filename' => 'modSystemSetting/d9b8232ef9c8837730fc7a81404a7636.vehicle',
    ),
    221 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '63e0e2faad51c10c6a91e2aefa83402b',
      'native_key' => 'cache_db_expires',
      'filename' => 'modSystemSetting/cf4d615d7172619de7ce76b7e0d4e4ed.vehicle',
    ),
    222 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '32e95b3b17941422d65a8a9f60f4a809',
      'native_key' => 'cache_db_session',
      'filename' => 'modSystemSetting/f60f44f4976ec99830f73bfc36d579e1.vehicle',
    ),
    223 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '268ba36bf7168c067303522a201a9e90',
      'native_key' => 'cache_db_session_lifetime',
      'filename' => 'modSystemSetting/ab0624ba58d46fbbfb673c33ba54a0a9.vehicle',
    ),
    224 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3aed7ddce6517cd4fd9ace7e4d4b59d6',
      'native_key' => 'cache_default',
      'filename' => 'modSystemSetting/8c2b19b15aa56d5274c7d0cd2731aa4b.vehicle',
    ),
    225 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9dff1cc0b2f1c6b0a8ec0738c6a2b124',
      'native_key' => 'cache_disabled',
      'filename' => 'modSystemSetting/02a9e202a7aca8eabcc0778b525b3615.vehicle',
    ),
    226 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e1072e6ec2a80b0f850e2c233a45c923',
      'native_key' => 'cache_expires',
      'filename' => 'modSystemSetting/d6085277c2a8e503f3f52da23ecba76e.vehicle',
    ),
    227 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e7938418a6b2719e2d98f397b46fe960',
      'native_key' => 'cache_format',
      'filename' => 'modSystemSetting/10b497133b550beeb66ed2041f38d30e.vehicle',
    ),
    228 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '56a2dfcfbdd79fca32b8c0e2ae80f934',
      'native_key' => 'cache_handler',
      'filename' => 'modSystemSetting/cf44e604e6e0c0115a999a88d64b9a40.vehicle',
    ),
    229 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b51d74d87281fd0671554547db68d663',
      'native_key' => 'cache_lang_js',
      'filename' => 'modSystemSetting/ab858098c8fbbdb5936eccd98e01d3ed.vehicle',
    ),
    230 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5d4015273ad237d471e638a15ebd8227',
      'native_key' => 'cache_lexicon_topics',
      'filename' => 'modSystemSetting/09e7f54af132015de846ede2b248b49b.vehicle',
    ),
    231 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ec97b3f9ff6306ed53a4451b7865e8eb',
      'native_key' => 'cache_noncore_lexicon_topics',
      'filename' => 'modSystemSetting/1e0f35c14e11c158f0fc9ac37ec9acb5.vehicle',
    ),
    232 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '06ad6b1a1cebe83fc91086ba4de6c55b',
      'native_key' => 'cache_resource',
      'filename' => 'modSystemSetting/4000038ab913dbe66aa5b5c92b749c79.vehicle',
    ),
    233 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1bf36731611ea0b7918ddbebfd2871f9',
      'native_key' => 'cache_resource_expires',
      'filename' => 'modSystemSetting/be090941261e27207786d65a548ee96a.vehicle',
    ),
    234 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd317e9d1ddcee34045d1308dfa3b83f7',
      'native_key' => 'cache_scripts',
      'filename' => 'modSystemSetting/23cb87ec676159a39d81cacd01b65a46.vehicle',
    ),
    235 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a635611217d348c8206892b9764006a7',
      'native_key' => 'cache_system_settings',
      'filename' => 'modSystemSetting/cb14c2ed121250373cf060577d84c5f0.vehicle',
    ),
    236 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4ab8768f7772a41060e1891600b3b828',
      'native_key' => 'clear_cache_refresh_trees',
      'filename' => 'modSystemSetting/2edd542683f5abcff8bdcb2587544659.vehicle',
    ),
    237 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6425bce17b6b2bcdc6ec9d55a98583c5',
      'native_key' => 'compress_css',
      'filename' => 'modSystemSetting/c9631ad60db28b900d92f4f36e3b1c2d.vehicle',
    ),
    238 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0562b6d9745869ac37c891a9bcb56f8e',
      'native_key' => 'compress_js',
      'filename' => 'modSystemSetting/c61815b040261385db5a8a33d2666ddd.vehicle',
    ),
    239 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f808b3a4a9daa9dcdb682aac5d27f1f8',
      'native_key' => 'compress_js_max_files',
      'filename' => 'modSystemSetting/bb71825f552bc6e45049fdd424505788.vehicle',
    ),
    240 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '26a13a8235e2a652a656e146be2c374e',
      'native_key' => 'confirm_navigation',
      'filename' => 'modSystemSetting/48c0d73d8336e12455ba8d717985c1b7.vehicle',
    ),
    241 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1d047fd1dae877b7629c1212f34d32ea',
      'native_key' => 'container_suffix',
      'filename' => 'modSystemSetting/6fb92c1e3755fdaa5413a261013baa57.vehicle',
    ),
    242 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6eed98da3227e595274873d798a1af12',
      'native_key' => 'context_tree_sort',
      'filename' => 'modSystemSetting/778b23d78df90e3979159253a9155554.vehicle',
    ),
    243 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f659c98e3b384ae36e3e0d522798644f',
      'native_key' => 'context_tree_sortby',
      'filename' => 'modSystemSetting/4b464b36919d116647239c842a56d74b.vehicle',
    ),
    244 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e17b501b0567458cbd85784fb5c1642c',
      'native_key' => 'context_tree_sortdir',
      'filename' => 'modSystemSetting/06e30116d1abde857d8a8460627e7012.vehicle',
    ),
    245 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5249eb358ac643dc1931e46b3558de00',
      'native_key' => 'cultureKey',
      'filename' => 'modSystemSetting/d1c101569a5783b5c3f985247acbb0f9.vehicle',
    ),
    246 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5ef3f364d2786e93b5acbd0092b5e80e',
      'native_key' => 'date_timezone',
      'filename' => 'modSystemSetting/d42087aa5fa98f0c3042437bf5dcac76.vehicle',
    ),
    247 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '21764b7645b533149d75d73282772316',
      'native_key' => 'debug',
      'filename' => 'modSystemSetting/7f6308fc1948d0d1a318a2e14a5f6c61.vehicle',
    ),
    248 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6ea9cad24f2f3ec2ea77f3a317c8b618',
      'native_key' => 'default_duplicate_publish_option',
      'filename' => 'modSystemSetting/4250c9df4f4c1285562d3f448bebd0f9.vehicle',
    ),
    249 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '233adf51fb85e2dcc691de82f175ac85',
      'native_key' => 'default_media_source',
      'filename' => 'modSystemSetting/d93115d612419808590772d90ed9e45b.vehicle',
    ),
    250 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '393d395e82f4a983babb24ae20fe62ed',
      'native_key' => 'default_per_page',
      'filename' => 'modSystemSetting/1861f418a282c788d545c2b08d8a2651.vehicle',
    ),
    251 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e7e214c78b712effb5564e6c2bcf3b70',
      'native_key' => 'default_context',
      'filename' => 'modSystemSetting/12ecc14267e95e74828b4597dfdcc160.vehicle',
    ),
    252 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8d286f103594b68d2385f1a9486ee326',
      'native_key' => 'default_template',
      'filename' => 'modSystemSetting/c2038484e086754b35c61b0c790a0b76.vehicle',
    ),
    253 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '17b110b0b2c895b3ecaa5e272f3fd2ae',
      'native_key' => 'default_content_type',
      'filename' => 'modSystemSetting/d7239710d7d92ae119ccfba2fe8d05df.vehicle',
    ),
    254 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e675682b7b9ccfc770cb5db3f064548a',
      'native_key' => 'editor_css_path',
      'filename' => 'modSystemSetting/0660015704909f5bea5a3ed55cd06010.vehicle',
    ),
    255 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4c03338b47a5972bfd19615f2fc09ebe',
      'native_key' => 'editor_css_selectors',
      'filename' => 'modSystemSetting/f75c1d492c919b88f06d346d95c79b09.vehicle',
    ),
    256 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7f79762da48cf32a6fab1e0ddec3daf4',
      'native_key' => 'emailsender',
      'filename' => 'modSystemSetting/1cb34fe38959b3692fdcdbfe5e471690.vehicle',
    ),
    257 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9ea33bddd7854c13899160a1ca77bd1e',
      'native_key' => 'emailsubject',
      'filename' => 'modSystemSetting/17d1af983d5bb23cbef37e1b71dc959f.vehicle',
    ),
    258 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6a058f1abf6c148cc235e9cc11926b9a',
      'native_key' => 'enable_dragdrop',
      'filename' => 'modSystemSetting/1cf4df8fa9adb60ef4f9b31690433346.vehicle',
    ),
    259 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'be911cee6874b01e862b056af8b53720',
      'native_key' => 'error_page',
      'filename' => 'modSystemSetting/36d30975eb66aa7ed3e053961e05dcc6.vehicle',
    ),
    260 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '06efcfaf17ff2d16cc8b846c52fca254',
      'native_key' => 'failed_login_attempts',
      'filename' => 'modSystemSetting/5b9a0be6f81bb068cf441655149eba27.vehicle',
    ),
    261 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '06cd21d31d3579fba1f48c25ecfbf81d',
      'native_key' => 'fe_editor_lang',
      'filename' => 'modSystemSetting/752f37cadae5edc9e24cb0740d86e6ae.vehicle',
    ),
    262 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c5f1bffdbc5232f9b9f912d5aa4fe59e',
      'native_key' => 'feed_modx_news',
      'filename' => 'modSystemSetting/852b3eb464da968e624845b737697361.vehicle',
    ),
    263 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '48e65389d98eb423f2d1c3fee614f406',
      'native_key' => 'feed_modx_news_enabled',
      'filename' => 'modSystemSetting/f5c9804dc7d0aecc813e350212f41979.vehicle',
    ),
    264 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eae04d1aeecb5d8e611dc8676471bab4',
      'native_key' => 'feed_modx_security',
      'filename' => 'modSystemSetting/f13043a9e3b6cde5f61baf1c6b04f1fb.vehicle',
    ),
    265 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e1c1e9876d3224656c1d047c393a2961',
      'native_key' => 'feed_modx_security_enabled',
      'filename' => 'modSystemSetting/1d3ea41bdc042043d1c9f6e2f4aad85d.vehicle',
    ),
    266 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7f8da3ecce506da40ba91c16c1b5cfdd',
      'native_key' => 'filemanager_path',
      'filename' => 'modSystemSetting/9a05b37b65f2c1ed1d3b74fe3805129d.vehicle',
    ),
    267 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd9027d7c96b9a106c70d6f754443fd8e',
      'native_key' => 'filemanager_path_relative',
      'filename' => 'modSystemSetting/63b1e522283967914c98399b77d10c56.vehicle',
    ),
    268 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '396f0d6f2f2306757dbc6c74d4a48457',
      'native_key' => 'filemanager_url',
      'filename' => 'modSystemSetting/123fd4f494a61a70bc1c849d7c86c31c.vehicle',
    ),
    269 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '87791c08a5858cd86e5410391df26bd4',
      'native_key' => 'filemanager_url_relative',
      'filename' => 'modSystemSetting/ef870611477fc6d4d6fe3117f7a7b140.vehicle',
    ),
    270 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a64350b03cf3b061482cbab72048ad42',
      'native_key' => 'forgot_login_email',
      'filename' => 'modSystemSetting/c7622b4558d087d31a60848baf8f0546.vehicle',
    ),
    271 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'db74420f920b428162ec8ba8fece398e',
      'native_key' => 'form_customization_use_all_groups',
      'filename' => 'modSystemSetting/278f6898e7acf96cd106712262b0b66c.vehicle',
    ),
    272 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8a503b39e8bb8cb5cce9de0122e70177',
      'native_key' => 'forward_merge_excludes',
      'filename' => 'modSystemSetting/abf1ccfbf60cef3b482cbd6401c6b935.vehicle',
    ),
    273 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8f843166d29328a9773736e586fda5b8',
      'native_key' => 'friendly_alias_lowercase_only',
      'filename' => 'modSystemSetting/624f5ae6a27a7afef6e0296e843a57d6.vehicle',
    ),
    274 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '33a6099ad7e89a7c6fe6ed397bbb0df5',
      'native_key' => 'friendly_alias_max_length',
      'filename' => 'modSystemSetting/88ea3aa20c76bae36d519abfd3786e42.vehicle',
    ),
    275 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '60e2bd9b4300e90e1ab7196848c559dc',
      'native_key' => 'friendly_alias_realtime',
      'filename' => 'modSystemSetting/7605d24af8bdd88cfdc2457cd0fcf956.vehicle',
    ),
    276 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3468c862e8e5745d7d7110f8bf230229',
      'native_key' => 'friendly_alias_restrict_chars',
      'filename' => 'modSystemSetting/82b15cc3485dc26851c4714ac98437d4.vehicle',
    ),
    277 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1e984c550b4335c389bf7b76b1edddf2',
      'native_key' => 'friendly_alias_restrict_chars_pattern',
      'filename' => 'modSystemSetting/669846d9b3a10660de03d41ee274fe02.vehicle',
    ),
    278 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '05c585b05296ae75dfd486385e355aee',
      'native_key' => 'friendly_alias_strip_element_tags',
      'filename' => 'modSystemSetting/0d0fa79d773628368b37e3d07361bd9c.vehicle',
    ),
    279 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9cfde3c279158b81a33e1faa998dec87',
      'native_key' => 'friendly_alias_translit',
      'filename' => 'modSystemSetting/6a4ef46a849e01b15cfcccad312a33fb.vehicle',
    ),
    280 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9645a508796eebe162800765220e99db',
      'native_key' => 'friendly_alias_translit_class',
      'filename' => 'modSystemSetting/b313fc86a6a1dbeeb174972859780c9c.vehicle',
    ),
    281 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '21f82d753c7cc4cd995c99c91b185154',
      'native_key' => 'friendly_alias_translit_class_path',
      'filename' => 'modSystemSetting/3e1ecc535b862ea9719148ec104c633f.vehicle',
    ),
    282 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dc4c0211877f02bea09233537cb00892',
      'native_key' => 'friendly_alias_trim_chars',
      'filename' => 'modSystemSetting/33005db084f77723b15068b3aaf2521f.vehicle',
    ),
    283 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2015ad2fc9851b0e3c8da694183941e3',
      'native_key' => 'friendly_alias_word_delimiter',
      'filename' => 'modSystemSetting/1e28e3b4e6d9878ea5f1efec0e36b0f0.vehicle',
    ),
    284 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e6cf70e4486da9237d667761b2eb84b2',
      'native_key' => 'friendly_alias_word_delimiters',
      'filename' => 'modSystemSetting/7c1dcb9315b11769d9987e73bd7c9b8f.vehicle',
    ),
    285 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '75f3daaef9af41dae53cf43906cae0bc',
      'native_key' => 'friendly_urls',
      'filename' => 'modSystemSetting/ae6d59550f5327890bfd4daef7dc6303.vehicle',
    ),
    286 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7e2cf336f8dcfc4f2b193b4766924889',
      'native_key' => 'friendly_urls_strict',
      'filename' => 'modSystemSetting/652a1aed13d6521af011a97ac7c9bb55.vehicle',
    ),
    287 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4c5df434e7eda8557441cb1d6e041d38',
      'native_key' => 'use_frozen_parent_uris',
      'filename' => 'modSystemSetting/db1f1bdec7b5aea4db637fd6e6272fd8.vehicle',
    ),
    288 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '46005fab6edb0d250113f85a020ca286',
      'native_key' => 'global_duplicate_uri_check',
      'filename' => 'modSystemSetting/270c278bb4e4ba4e2d774d43e36cbddd.vehicle',
    ),
    289 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '14548beec26ab682c162ebbad154899b',
      'native_key' => 'hidemenu_default',
      'filename' => 'modSystemSetting/ecb069a68b85bbaa70490dc0761e9636.vehicle',
    ),
    290 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '75e8804eb5dceab191409c32de994df9',
      'native_key' => 'inline_help',
      'filename' => 'modSystemSetting/336a3496233237965ae133ae970ebc18.vehicle',
    ),
    291 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cfb66b418dce0250440bf8d33b0da8fb',
      'native_key' => 'locale',
      'filename' => 'modSystemSetting/37eb6aa462d329ed049b44e79a35a81e.vehicle',
    ),
    292 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '54ce4acd8b2a7a67b4f39f2a4e5ed337',
      'native_key' => 'log_level',
      'filename' => 'modSystemSetting/1608d4094d1dfca4b464aa72e8fc2985.vehicle',
    ),
    293 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3d77bed3443bc821baa150c589a8320e',
      'native_key' => 'log_target',
      'filename' => 'modSystemSetting/3492759a2b2c54d382711abfa3f4598d.vehicle',
    ),
    294 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '193ee6959f0a0aee7d4eea0b650b2569',
      'native_key' => 'link_tag_scheme',
      'filename' => 'modSystemSetting/db74b4556b3aae27f3615c85aa63c02c.vehicle',
    ),
    295 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '230bdd2c9c946df4718a1a22201e3278',
      'native_key' => 'lock_ttl',
      'filename' => 'modSystemSetting/a4117497f0c037ed17245bae7792b554.vehicle',
    ),
    296 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cc9c61256e6cb05ce0e192ab5c373d30',
      'native_key' => 'mail_charset',
      'filename' => 'modSystemSetting/675628748cc3580fd3e5eb181d06e6e2.vehicle',
    ),
    297 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f6565eb7e8c05cc5b1b67833b2acb6a9',
      'native_key' => 'mail_encoding',
      'filename' => 'modSystemSetting/f0554e5f64ae948ef54f0c4b264b48ed.vehicle',
    ),
    298 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '47db82ce0c1371889a134e4a87e27a79',
      'native_key' => 'mail_use_smtp',
      'filename' => 'modSystemSetting/0d77276da4b4d3028baa585287e5fb9b.vehicle',
    ),
    299 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '80b3874af206f031a3b5f28c409b6748',
      'native_key' => 'mail_smtp_auth',
      'filename' => 'modSystemSetting/1d97b09f5abe38a3eaf23aa384509949.vehicle',
    ),
    300 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '90f0d2625f0c079195864234eee836ff',
      'native_key' => 'mail_smtp_helo',
      'filename' => 'modSystemSetting/342bd342d042fd57dd205fb7e11084f5.vehicle',
    ),
    301 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '64a020d5d5f16198c20306c505e8ac24',
      'native_key' => 'mail_smtp_hosts',
      'filename' => 'modSystemSetting/844b89c14184f6aae83ed3a6fc6cda7b.vehicle',
    ),
    302 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '237ea44ec1d0d8b685e31405cc96617b',
      'native_key' => 'mail_smtp_keepalive',
      'filename' => 'modSystemSetting/c8416e77b85dbf3a7642f41776d76e3f.vehicle',
    ),
    303 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2340cbd37acd1142e0b978930401e271',
      'native_key' => 'mail_smtp_pass',
      'filename' => 'modSystemSetting/9f8cb5bc19d190ff75839a6fa18956be.vehicle',
    ),
    304 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9a04c5d774219fea7491345561033c5e',
      'native_key' => 'mail_smtp_port',
      'filename' => 'modSystemSetting/363e07e2e9829d246bb8b50f8f4fcf16.vehicle',
    ),
    305 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '79177f69b7f430c1e46b4471c916eb99',
      'native_key' => 'mail_smtp_prefix',
      'filename' => 'modSystemSetting/491b74d1714e57ce3624c96a4e7d0de8.vehicle',
    ),
    306 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '411b05940690e88a80c99a5ed052c060',
      'native_key' => 'mail_smtp_single_to',
      'filename' => 'modSystemSetting/59b8a3a0ba6bdc01f0957b4818df2bc7.vehicle',
    ),
    307 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6f0006d9a9ecfa29b6fc2e13c081711e',
      'native_key' => 'mail_smtp_timeout',
      'filename' => 'modSystemSetting/07852204e2eb9de3015316e49a8456aa.vehicle',
    ),
    308 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '19290c8828b585a33f26b73c8f55afe0',
      'native_key' => 'mail_smtp_user',
      'filename' => 'modSystemSetting/85a2069dc8123fb2f9809162126727bd.vehicle',
    ),
    309 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ad3b8dec8f3677e445a9e398796a0a1f',
      'native_key' => 'manager_date_format',
      'filename' => 'modSystemSetting/ec140e8d3c635b492c9b0f47d57755d2.vehicle',
    ),
    310 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '233a268e6ed67852b50c388637cf8b5a',
      'native_key' => 'manager_favicon_url',
      'filename' => 'modSystemSetting/7eb2c3398f9b051fd36c1e92cd29a846.vehicle',
    ),
    311 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f85cfb11a9568cffd4fedd5cdeab5075',
      'native_key' => 'manager_js_cache_file_locking',
      'filename' => 'modSystemSetting/793eaa647a48d2405defd63b49f9766d.vehicle',
    ),
    312 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a600ecee9039ac430276d06deabc1f9b',
      'native_key' => 'manager_js_cache_max_age',
      'filename' => 'modSystemSetting/8f04d505d5a8f47eaeeeee0ff134fb8c.vehicle',
    ),
    313 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eb71c5bb1be73b5e94393c531f4094a1',
      'native_key' => 'manager_js_document_root',
      'filename' => 'modSystemSetting/6af3bd947c0d3346a1a05e3b1dac27c5.vehicle',
    ),
    314 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8ba1cc2af56979eb0280dda17e304d7e',
      'native_key' => 'manager_js_zlib_output_compression',
      'filename' => 'modSystemSetting/f617e7f15f150205b852951d3b1dd314.vehicle',
    ),
    315 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd9b6e32c108f94f6a1eff13047fd096c',
      'native_key' => 'manager_time_format',
      'filename' => 'modSystemSetting/acaa8827bedf6399e6a14e699362ca89.vehicle',
    ),
    316 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6afa6aa2148edd18fc860c79beb64065',
      'native_key' => 'manager_direction',
      'filename' => 'modSystemSetting/de0133670eb6f8fe94ea2aa4fad9a54d.vehicle',
    ),
    317 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9fb69e0a329a074ce8a7e3003acfd063',
      'native_key' => 'manager_lang_attribute',
      'filename' => 'modSystemSetting/134e351d6aa5a363a72213a39e557bfa.vehicle',
    ),
    318 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c2fe676315d342e205506b3065284b33',
      'native_key' => 'manager_language',
      'filename' => 'modSystemSetting/a2830f815363200ede1a13fae75b0176.vehicle',
    ),
    319 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5c5ca943b8cdab11ace2467d48eb92c3',
      'native_key' => 'manager_login_url_alternate',
      'filename' => 'modSystemSetting/04fed24476d6312041e43c73db4f0abb.vehicle',
    ),
    320 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fd9e9a049621f188a11ed102d7bc0ac4',
      'native_key' => 'manager_theme',
      'filename' => 'modSystemSetting/767bfa1e57518ef3af6e7524d9c8d062.vehicle',
    ),
    321 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '99603e4507c70e693a69a2487aecaedd',
      'native_key' => 'manager_week_start',
      'filename' => 'modSystemSetting/756d4208c66ae0b476e91a1e0aabb76c.vehicle',
    ),
    322 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5adfe62122de5a6e88dbd7d3231b8a29',
      'native_key' => 'modx_browser_tree_hide_files',
      'filename' => 'modSystemSetting/1d6b29b711163b44527041939efd650c.vehicle',
    ),
    323 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '88575a977303451ab7b9fe5bda310f39',
      'native_key' => 'modx_browser_tree_hide_tooltips',
      'filename' => 'modSystemSetting/c739e4932ee277102c76d0dc14c55296.vehicle',
    ),
    324 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dd8e8625fba7122ba6b9204086cab441',
      'native_key' => 'modx_browser_default_sort',
      'filename' => 'modSystemSetting/47b8eb2d549296748b7324e9dd85c2f8.vehicle',
    ),
    325 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a3eca8f8ae7048a2af7bc93b5510e8b7',
      'native_key' => 'modx_browser_default_viewmode',
      'filename' => 'modSystemSetting/2ded4afd3cbbba35af78c0903b429b04.vehicle',
    ),
    326 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3fa1f3f7da580ceeca745b1ae8cefbcc',
      'native_key' => 'modx_charset',
      'filename' => 'modSystemSetting/42a56a897c734e64fac8d7148a510a67.vehicle',
    ),
    327 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '147fdd4646346ea4c10c5842f29b90dc',
      'native_key' => 'principal_targets',
      'filename' => 'modSystemSetting/1a3ef070bb1ebbf1cc016a52f7bb60b0.vehicle',
    ),
    328 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b8bcf836fed369e36f8a57777ccda063',
      'native_key' => 'proxy_auth_type',
      'filename' => 'modSystemSetting/fa3fd8a3cdae9a03ceb49037c42b1dde.vehicle',
    ),
    329 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6c767b00e67fcded7990783094a383f6',
      'native_key' => 'proxy_host',
      'filename' => 'modSystemSetting/d1506a93636b3b21fca9ae4185d91b33.vehicle',
    ),
    330 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd2726afab3848a40d56613d8db8e4602',
      'native_key' => 'proxy_password',
      'filename' => 'modSystemSetting/15a2692d0159ab61ff664a2033485ced.vehicle',
    ),
    331 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8d56c29af20a7b7983fcfe9b64e7d081',
      'native_key' => 'proxy_port',
      'filename' => 'modSystemSetting/dc95e84c48d1b55e42a93a6836a13782.vehicle',
    ),
    332 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eba61907e5354e8843fe09c341435d76',
      'native_key' => 'proxy_username',
      'filename' => 'modSystemSetting/2144442076e8f6a0cd83d294dcb3cfaf.vehicle',
    ),
    333 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f81b29c544fe61541c79fa40402247f1',
      'native_key' => 'password_generated_length',
      'filename' => 'modSystemSetting/d7d99c2a02b5ce1361f34d43d62ced42.vehicle',
    ),
    334 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a742ca956a3993cb266e94d44d764d07',
      'native_key' => 'password_min_length',
      'filename' => 'modSystemSetting/17a4a14f2f44bf5baf4c8371751bb525.vehicle',
    ),
    335 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a0f3ffe9801de90a230f5fb513916ede',
      'native_key' => 'phpthumb_allow_src_above_docroot',
      'filename' => 'modSystemSetting/3fcf10f99045f7e37e7ebc1ff4b91df0.vehicle',
    ),
    336 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b4f1936766713f09614cec605a8d7fa8',
      'native_key' => 'phpthumb_cache_maxage',
      'filename' => 'modSystemSetting/e4f7670f25ef2005ddcf479a16d0326b.vehicle',
    ),
    337 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ec3b4f304f8aada2684dab0125644e58',
      'native_key' => 'phpthumb_cache_maxsize',
      'filename' => 'modSystemSetting/720fab18a16e3e7d5533552db5ff3804.vehicle',
    ),
    338 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6cfc0dce01a4d2605ef95b4d95c0a4f0',
      'native_key' => 'phpthumb_cache_maxfiles',
      'filename' => 'modSystemSetting/38b55181e70269397857a2872e75d679.vehicle',
    ),
    339 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3f60416b3937f7d6f3b54c974bafb2fa',
      'native_key' => 'phpthumb_cache_source_enabled',
      'filename' => 'modSystemSetting/233d57e49fca5a51639f36523d427e9f.vehicle',
    ),
    340 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5327c7c311e540ed555313e821ee8bd2',
      'native_key' => 'phpthumb_document_root',
      'filename' => 'modSystemSetting/4c9f1896bf8f9e11234d114258c84e71.vehicle',
    ),
    341 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '36a70fe981a61720ca3fd867e4c5eebd',
      'native_key' => 'phpthumb_error_bgcolor',
      'filename' => 'modSystemSetting/a06de3bd5ac58888c90384a9c9ea5e59.vehicle',
    ),
    342 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3eda566f87450c2ff92e25e952a5c21e',
      'native_key' => 'phpthumb_error_textcolor',
      'filename' => 'modSystemSetting/7b7a4b449d4fdfe267d72be6119ef87a.vehicle',
    ),
    343 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f8da413b7682392052f3957413454680',
      'native_key' => 'phpthumb_error_fontsize',
      'filename' => 'modSystemSetting/5927d18d2a1b56e03363013de49d94eb.vehicle',
    ),
    344 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '307b458e1430cd9f3573ba5cf1d25e7a',
      'native_key' => 'phpthumb_far',
      'filename' => 'modSystemSetting/3ba65798f25e3339f24cb898cf5e7989.vehicle',
    ),
    345 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '67b55b637ff95f8138a32e1a19bda72c',
      'native_key' => 'phpthumb_imagemagick_path',
      'filename' => 'modSystemSetting/421d26ee7677ffc1c7b7e3d57eccff5b.vehicle',
    ),
    346 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'af6fdfd0ca58e99e023151035faf025f',
      'native_key' => 'phpthumb_nohotlink_enabled',
      'filename' => 'modSystemSetting/7041a808a16fac4e28116507ec5af1b6.vehicle',
    ),
    347 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7c7319d54cd0f94dccbb7cef7a2bffc1',
      'native_key' => 'phpthumb_nohotlink_erase_image',
      'filename' => 'modSystemSetting/65a6ddcdf79899894e7d06efc9815cbb.vehicle',
    ),
    348 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c878d24aa1862896c3953b8cf8319c32',
      'native_key' => 'phpthumb_nohotlink_valid_domains',
      'filename' => 'modSystemSetting/6aa0d696a98cdab8217f4a53b378e44d.vehicle',
    ),
    349 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1fd008be47046127545f455d87945614',
      'native_key' => 'phpthumb_nohotlink_text_message',
      'filename' => 'modSystemSetting/420da4b32645af4b14ed180faaa174fb.vehicle',
    ),
    350 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e7fdccca818f70934ea6a235a6276149',
      'native_key' => 'phpthumb_nooffsitelink_enabled',
      'filename' => 'modSystemSetting/dd9e010149f87b0f2676a5145868d017.vehicle',
    ),
    351 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ddf4528406a47ec9a0c3f6f18b90bc4d',
      'native_key' => 'phpthumb_nooffsitelink_erase_image',
      'filename' => 'modSystemSetting/c110218f20c5e36459ae1e1c9b85991f.vehicle',
    ),
    352 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3763fe08b07762353f1d1246e8264c6d',
      'native_key' => 'phpthumb_nooffsitelink_require_refer',
      'filename' => 'modSystemSetting/c8b655634a1b429669c9d87bb6093da2.vehicle',
    ),
    353 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b161c0a848e7b40b94f3af362a4600b2',
      'native_key' => 'phpthumb_nooffsitelink_text_message',
      'filename' => 'modSystemSetting/da688f33e34dd2cfaa5fb52d96680921.vehicle',
    ),
    354 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '11ec5d1e852a0c764784e1fab2f4da41',
      'native_key' => 'phpthumb_nooffsitelink_valid_domains',
      'filename' => 'modSystemSetting/dfa6e0b8fb1b1369ccffa91e64adfe2b.vehicle',
    ),
    355 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dd66ac6a298a22c1fd57213a97dafc76',
      'native_key' => 'phpthumb_nooffsitelink_watermark_src',
      'filename' => 'modSystemSetting/e6a6f0be29ff2a3b925c5c0042b24667.vehicle',
    ),
    356 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e718c596feb9b118394189bf490de119',
      'native_key' => 'phpthumb_zoomcrop',
      'filename' => 'modSystemSetting/25642d72de56cf5a758e7a23793f5641.vehicle',
    ),
    357 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '214a696fb88543b75a25dd07ec629073',
      'native_key' => 'publish_default',
      'filename' => 'modSystemSetting/27a36ed6b3c89b88b628b35b8bbfbd7d.vehicle',
    ),
    358 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e495204f7a71b8103d0a58fe07eda234',
      'native_key' => 'rb_base_dir',
      'filename' => 'modSystemSetting/8119ca4bc51275bdf86df19d78cb20af.vehicle',
    ),
    359 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '77bc3bf9e59103bd14c4264efa8f6e73',
      'native_key' => 'rb_base_url',
      'filename' => 'modSystemSetting/2fde09434e235d43e2035bbbeeba39db.vehicle',
    ),
    360 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3aed20a420c5b10d12b3012699c9369e',
      'native_key' => 'request_controller',
      'filename' => 'modSystemSetting/e1ca7a1478f66ba826649a072926766e.vehicle',
    ),
    361 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9cb6162fa5330ff6712f0e6bdb25d374',
      'native_key' => 'request_method_strict',
      'filename' => 'modSystemSetting/67c6e4630028ab188ec5b84b72d8f67c.vehicle',
    ),
    362 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fc115877fafc05da923e7cbe235f972e',
      'native_key' => 'request_param_alias',
      'filename' => 'modSystemSetting/28967ee8045716b932b1815261e3e6e5.vehicle',
    ),
    363 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '05925537cb51f948769e429344a45927',
      'native_key' => 'request_param_id',
      'filename' => 'modSystemSetting/00e44363d1a171808ecd7d9199ec8977.vehicle',
    ),
    364 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '721669963e3f29d837cd09084013d68f',
      'native_key' => 'resolve_hostnames',
      'filename' => 'modSystemSetting/1ba216a7bf9e7248a4eff3c70efc3b95.vehicle',
    ),
    365 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd51263cdcfa78c75ab0a8f9093913160',
      'native_key' => 'resource_tree_node_name',
      'filename' => 'modSystemSetting/d6a5d95bcb0b7a720e35183f81e8000e.vehicle',
    ),
    366 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5e258647df8679eaf373fce5c45f3a8f',
      'native_key' => 'resource_tree_node_name_fallback',
      'filename' => 'modSystemSetting/83832bad14c572c62f382c5b9edb8e17.vehicle',
    ),
    367 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a5bba17b8605fdf6acacb287981a6693',
      'native_key' => 'resource_tree_node_tooltip',
      'filename' => 'modSystemSetting/9a93f9301f0bf6a460b25e7ab95065fa.vehicle',
    ),
    368 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e8eb32c627381ed2d68374837850853f',
      'native_key' => 'richtext_default',
      'filename' => 'modSystemSetting/225d52ea9cc7fc563aa997d06f67ffbf.vehicle',
    ),
    369 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ef4a135c0b4ead0b00bb813b076197d7',
      'native_key' => 'search_default',
      'filename' => 'modSystemSetting/5c557433310ca43722451e93a8baee7a.vehicle',
    ),
    370 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f2b2334221bd3f5959556449e226a0a0',
      'native_key' => 'server_offset_time',
      'filename' => 'modSystemSetting/718ce455082736a93437542ec7f8c6a3.vehicle',
    ),
    371 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2d2fa4546d8536eb8edee507711d8616',
      'native_key' => 'server_protocol',
      'filename' => 'modSystemSetting/341cf46c3ed0e2792f31a8c2b08a0961.vehicle',
    ),
    372 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2a1caf39240d4c9771c4277233655518',
      'native_key' => 'session_cookie_domain',
      'filename' => 'modSystemSetting/4696cc6ba524d08f4f07331a3fa2e60c.vehicle',
    ),
    373 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '767a481b63d2b57802f3231515434531',
      'native_key' => 'default_username',
      'filename' => 'modSystemSetting/c2414c3a8c809b8149c9efe52e206a20.vehicle',
    ),
    374 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e91840088b4ce2660a2643b511ba0776',
      'native_key' => 'anonymous_sessions',
      'filename' => 'modSystemSetting/e51b08a915b17fbf1cfee01d3e22e7da.vehicle',
    ),
    375 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eae607b266c4b17dce6cdad3e885b5e4',
      'native_key' => 'session_cookie_lifetime',
      'filename' => 'modSystemSetting/d414f8e228b8523b2659b1f0eee28bc4.vehicle',
    ),
    376 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3533dc7857b4287e7b4cbc243cc98231',
      'native_key' => 'session_cookie_path',
      'filename' => 'modSystemSetting/c8d601fd89161beee1911a32a403b4c6.vehicle',
    ),
    377 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1f65dae3430763330bb5f975adf5cdc4',
      'native_key' => 'session_cookie_secure',
      'filename' => 'modSystemSetting/830675010d17fa3df10ab0e2e121fd8d.vehicle',
    ),
    378 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '61fd73aee4ddbfe36833304c8382b759',
      'native_key' => 'session_cookie_httponly',
      'filename' => 'modSystemSetting/caf5c05afea50b2a8ddd4c9764094b9e.vehicle',
    ),
    379 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd764b1d3825133200f80a3ece89f6dd3',
      'native_key' => 'session_gc_maxlifetime',
      'filename' => 'modSystemSetting/6b6a3e9f7012cef55fb05a4ec375d38f.vehicle',
    ),
    380 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5f35db96c6722688b1f51b7e360244ce',
      'native_key' => 'session_handler_class',
      'filename' => 'modSystemSetting/392809f868334658725cc2c325937377.vehicle',
    ),
    381 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd3daa1d7dca32c5851dd44313abb2ec6',
      'native_key' => 'session_name',
      'filename' => 'modSystemSetting/ea4ff36cfe8694974da058fb33c52afa.vehicle',
    ),
    382 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a1701a5a8cae0873f8b49c2f3826d315',
      'native_key' => 'set_header',
      'filename' => 'modSystemSetting/e02134d03147b97c7bc573ddf4712c77.vehicle',
    ),
    383 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c415e225d352d20ebdefdf325c2ec136',
      'native_key' => 'send_poweredby_header',
      'filename' => 'modSystemSetting/1e93a8d05636a31c9d0f822bf0f1a2b8.vehicle',
    ),
    384 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b89ecfea907c0c01fbbe0ea0efa5e1f5',
      'native_key' => 'show_tv_categories_header',
      'filename' => 'modSystemSetting/ef39baba938fe0e3b4cd4ffbcc7e1ad2.vehicle',
    ),
    385 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '00b369f4a2ea7fa499ebc14af22bec6a',
      'native_key' => 'signupemail_message',
      'filename' => 'modSystemSetting/925dbf16b346c7892325ad50e06af1c2.vehicle',
    ),
    386 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '93108b29fe121ee65d8448521f776742',
      'native_key' => 'site_name',
      'filename' => 'modSystemSetting/00d4f2e19fbdd8db72b91387aff39518.vehicle',
    ),
    387 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cfb021e0ad823e5f255df52e0634c009',
      'native_key' => 'site_start',
      'filename' => 'modSystemSetting/0a9515324dad656924e7019dde72868e.vehicle',
    ),
    388 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '010c6712008cde483c9ed734377aff3d',
      'native_key' => 'site_status',
      'filename' => 'modSystemSetting/c80a2a321d9c5b9781d3e271cd5b39d4.vehicle',
    ),
    389 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '851de798579b468a7bfc43c1218f1155',
      'native_key' => 'site_unavailable_message',
      'filename' => 'modSystemSetting/7b3aba3775e82cba51f548004f042199.vehicle',
    ),
    390 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd0908e4f1227c236c8f85ac952462427',
      'native_key' => 'site_unavailable_page',
      'filename' => 'modSystemSetting/4f6be64b1be67f40705fbf19955eabfa.vehicle',
    ),
    391 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '513fa188e154bae24c3edeb36ed03cbc',
      'native_key' => 'strip_image_paths',
      'filename' => 'modSystemSetting/296fee4acaf21396b91dc048d78f1363.vehicle',
    ),
    392 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7859d65272fd697121cf7bb9e16817ee',
      'native_key' => 'symlink_merge_fields',
      'filename' => 'modSystemSetting/dadd02cebfe6e8dc00e59aea20765fae.vehicle',
    ),
    393 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '54eae8d3b0478c2a4edb9e12cfbd810c',
      'native_key' => 'syncsite_default',
      'filename' => 'modSystemSetting/c1902f7015a75fb42e0601bb096ca133.vehicle',
    ),
    394 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '739f555e48cb6ab141510aa394c329e0',
      'native_key' => 'topmenu_show_descriptions',
      'filename' => 'modSystemSetting/19bbe4dd141e50c62d13dfac8b08b132.vehicle',
    ),
    395 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0bb1c02d91732c991266ebedcaccb335',
      'native_key' => 'tree_default_sort',
      'filename' => 'modSystemSetting/e322e55807a48ad47020c74eed1a4779.vehicle',
    ),
    396 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6bf46a2370cce33dfbf421fe9901b4b4',
      'native_key' => 'tree_root_id',
      'filename' => 'modSystemSetting/9f79dc9e37c988a839434162096022c1.vehicle',
    ),
    397 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3d7ad39d7491842afe6cda1325629cf2',
      'native_key' => 'tvs_below_content',
      'filename' => 'modSystemSetting/c86d57ac53ca6b4db92fc6c98f944d30.vehicle',
    ),
    398 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8eb401b69ea91cd3ce23acebbd9bcf0d',
      'native_key' => 'udperms_allowroot',
      'filename' => 'modSystemSetting/8ea2da1f5d9c7812d31a8319758d2ea8.vehicle',
    ),
    399 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3184f45318a3ac0c24569c10817e32bf',
      'native_key' => 'unauthorized_page',
      'filename' => 'modSystemSetting/01c24ba5f4372eb4dc05fc9b94709ead.vehicle',
    ),
    400 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3d5064e0a9d2156d93c310ad380e3e45',
      'native_key' => 'upload_files',
      'filename' => 'modSystemSetting/8c9e280e51457b533b00b352938af874.vehicle',
    ),
    401 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '46d8883d45c3f2cb0f0575e587a55539',
      'native_key' => 'upload_flash',
      'filename' => 'modSystemSetting/046c91cd367f412dbb336ec119e5310c.vehicle',
    ),
    402 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1fae5534b50c66e700f24313e2bd71f1',
      'native_key' => 'upload_images',
      'filename' => 'modSystemSetting/faf2eb34e966337c328b8009bddd266d.vehicle',
    ),
    403 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'aa846801f2100678486bcb33cc8b9ae8',
      'native_key' => 'upload_maxsize',
      'filename' => 'modSystemSetting/3172e23c930818674605027b280089e4.vehicle',
    ),
    404 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4fb134f8257e22eda65d67ed39c554f4',
      'native_key' => 'upload_media',
      'filename' => 'modSystemSetting/387664b8f2f503bce26876dc11e0f56a.vehicle',
    ),
    405 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '390bf879ce0ce03701c5886871ca078f',
      'native_key' => 'use_alias_path',
      'filename' => 'modSystemSetting/051c1a72d3a58a5adc889d1b634fbb1a.vehicle',
    ),
    406 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '616564d9d1dd1de330a9e9477bc4c224',
      'native_key' => 'use_browser',
      'filename' => 'modSystemSetting/f49cb2b21d36a5e94b4d6a4b91a41a88.vehicle',
    ),
    407 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b2afbb2eddc6fe4abbc02233d2cd8d70',
      'native_key' => 'use_editor',
      'filename' => 'modSystemSetting/265f6de6f6e3b6bb7bb493fe797bef03.vehicle',
    ),
    408 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '194c2a9c5443651bd8920d41415cfbd3',
      'native_key' => 'use_multibyte',
      'filename' => 'modSystemSetting/a7ec55e3fc3f722f46be1623e4fd443c.vehicle',
    ),
    409 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bafcdfb44770ef3e6fd182fe4ee677a7',
      'native_key' => 'use_weblink_target',
      'filename' => 'modSystemSetting/4a0289100a790e3501edd102548d1e13.vehicle',
    ),
    410 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '12b662ab3861ae552ca4c2e6ae48bcee',
      'native_key' => 'webpwdreminder_message',
      'filename' => 'modSystemSetting/32bf056578219d2fa2c9271fe613d199.vehicle',
    ),
    411 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '039daa60b7ca5de7b7f94440d7a5849b',
      'native_key' => 'websignupemail_message',
      'filename' => 'modSystemSetting/89d349b977093b47e75381a97a150cf8.vehicle',
    ),
    412 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '35e936d9dba4737c5cffedd82182b92b',
      'native_key' => 'welcome_screen',
      'filename' => 'modSystemSetting/119d8c37fdc00a800fb9062b7700be04.vehicle',
    ),
    413 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b6a5260cd419f37fb62431a9efe6884f',
      'native_key' => 'welcome_screen_url',
      'filename' => 'modSystemSetting/f340b13620d385d434e4d3443fd5ede2.vehicle',
    ),
    414 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fff9fcfede83533e241dd8c1455e3971',
      'native_key' => 'welcome_action',
      'filename' => 'modSystemSetting/a9145ab52066ce9645348aaef1624927.vehicle',
    ),
    415 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4f6f09683b9a5862521cff9ea41309b0',
      'native_key' => 'welcome_namespace',
      'filename' => 'modSystemSetting/77a8e87d5d9a286db5aa206ae1396ca2.vehicle',
    ),
    416 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2d337b3c4f8793d57a22eb8dd94cbd21',
      'native_key' => 'which_editor',
      'filename' => 'modSystemSetting/3c06e02c3918f3b9cf9cf505fcbeb2f2.vehicle',
    ),
    417 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c39c491781b40d303a00f9341aa3eaa2',
      'native_key' => 'which_element_editor',
      'filename' => 'modSystemSetting/38b54adf7d84abc3626231c2d21166a6.vehicle',
    ),
    418 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1945bbbc89e0b2e9d2d7a47b7214974e',
      'native_key' => 'xhtml_urls',
      'filename' => 'modSystemSetting/fab3d39224418281a92e27e649ded7a4.vehicle',
    ),
    419 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '11ab52942da5c16b637ddd117171e8d8',
      'native_key' => 'enable_gravatar',
      'filename' => 'modSystemSetting/82d723f755f13833bd3f1dad65055e31.vehicle',
    ),
    420 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8e8d4cc1db70d9eb4efa253589f1d6ae',
      'native_key' => 'mgr_tree_icon_context',
      'filename' => 'modSystemSetting/abf48eab7fd398acc124f3fa8599d551.vehicle',
    ),
    421 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6c4c1ecd95c97f09a697fae753f308eb',
      'native_key' => 'mgr_source_icon',
      'filename' => 'modSystemSetting/66c1a30fe9f218553b0e702145ae02dc.vehicle',
    ),
    422 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '69dbd6e7f7e87d7f624c1d854935b52d',
      'native_key' => 'main_nav_parent',
      'filename' => 'modSystemSetting/a2025aa8288bc416a09f197453e2a40f.vehicle',
    ),
    423 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '59d5aee63c801e5cba330b0c83b92525',
      'native_key' => 'user_nav_parent',
      'filename' => 'modSystemSetting/e787f6a3b040e877d6a6028a1f45fa6e.vehicle',
    ),
    424 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b04fe90f158c3b2fc5fb59cfb9482ef3',
      'native_key' => 'auto_isfolder',
      'filename' => 'modSystemSetting/a43170177e2a95f925267d7e7e55ed88.vehicle',
    ),
    425 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '196544f65afd980ebd362f431c62ad80',
      'native_key' => 'manager_use_fullname',
      'filename' => 'modSystemSetting/6e9b0c729d5ed7f8878d5811959b5e73.vehicle',
    ),
    426 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dbc94d4289636299862eedeb1882b373',
      'native_key' => 'parser_recurse_uncacheable',
      'filename' => 'modSystemSetting/a42886cf1b4dd37a96a2c24a38212bdc.vehicle',
    ),
    427 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2aeaebc597bced982f1110fa06aa8beb',
      'native_key' => 'preserve_menuindex',
      'filename' => 'modSystemSetting/959df05cc4fc5b8741499d46a40af0b8.vehicle',
    ),
    428 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '0d042ea3a1538b2551af842132da2b30',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'allow_tags_in_post',
      ),
      'filename' => 'modContextSetting/b3bf17662ec1b79f742a3c072171448d.vehicle',
    ),
    429 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => 'db9f2bb95511112a5fa0b3482dc78111',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'modRequest.class',
      ),
      'filename' => 'modContextSetting/a23fc7514dcdd2b614cdd9a9b41c73f4.vehicle',
    ),
    430 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroup',
      'guid' => '2af5ace95a5785ccc5481be05339b848',
      'native_key' => 1,
      'filename' => 'modUserGroup/767681fb98f13e0c500c1a23ea49057a.vehicle',
    ),
    431 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboard',
      'guid' => 'b1f7cb476c2653baaf077fc17858a943',
      'native_key' => 1,
      'filename' => 'modDashboard/e4ecbfaa3d01ae8312f0b0ef37b0e51e.vehicle',
    ),
    432 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMediaSource',
      'guid' => '7f9aeb9ea61295d63da43ab35b9ad775',
      'native_key' => 1,
      'filename' => 'modMediaSource/82aa83789aa80e66c8a151edb0b55f9d.vehicle',
    ),
    433 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'ad91311c43832b31a53b3d540cb48ee1',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/f2b35b1047b9f285fddc87cae5457a1b.vehicle',
    ),
    434 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'af45c22a4e2fd3aa3f900be3dd05a5a0',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/2c51ab53684af31dd9389be3897db472.vehicle',
    ),
    435 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '4a79c64ef71c5af03b01d6a10df989fd',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/89eee4ad10b07e1d812deddfcbd5dbb8.vehicle',
    ),
    436 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '3cf67bf271962fe9f0d2031db75b9ae5',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/d71fa8daaf5b0e8926ff7c2305bee586.vehicle',
    ),
    437 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '97943c5d1c2ac5355d76f83b87ce9ca4',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/88f768f218e4f28e52b4c87d92ade5c0.vehicle',
    ),
    438 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => 'eedba02aaa7e56165edb1489f9d39a50',
      'native_key' => 1,
      'filename' => 'modUserGroupRole/271291872d47cf5a35d7e743c483ff5c.vehicle',
    ),
    439 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => 'cae24c35f04626162b5208caa405f94f',
      'native_key' => 2,
      'filename' => 'modUserGroupRole/bc773d35342c5457279bbce1f09e90a6.vehicle',
    ),
    440 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'ec63d52cc6e6a9833a3da96249a0aaa8',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/506949ddf10ef5cb0db16b9e8b41aff6.vehicle',
    ),
    441 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'e903750bfd9edcb9fb6ec6964842ae03',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/0eab85cdf24e6aa900e04df7bf057e5b.vehicle',
    ),
    442 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'b299fda0320a6bd4013f119a20a2a626',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/2f0fbccd8baa9434dda76fb4720152ea.vehicle',
    ),
    443 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'e9078b2b5144bc7cc186c33480686255',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/d54ac939b58e078f4bd58ed9730a9d31.vehicle',
    ),
    444 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'becd01db490a46b24672504e9658a334',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/7c8dba48db21eb7e5d185c5899898ad9.vehicle',
    ),
    445 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'a19f652c5a756718636b558bd3060a72',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/42103ef5308cf57afc58d725c790d120.vehicle',
    ),
    446 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'afffdc4cdfe3e144caa2134472d49012',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/c941a28449cfa8a9f9b73b0f410fda53.vehicle',
    ),
    447 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '9bcb7faad51cb9d65cb94edb4ba60eda',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/e68a3b54d1714d49716000e1a1337a6c.vehicle',
    ),
    448 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'a19af72d90bcf35b3e350e67654169f5',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/5861212fdab69ca2f6746e1b6d25b09b.vehicle',
    ),
    449 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '062d0646821a6c1df8c667ca6436d227',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/445ef2311c10c5ffc48616b4a219a1ec.vehicle',
    ),
    450 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '45b3d3df67f35d54de61407589a40bc0',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/fb154098cb00122cf7f7f2b69994ae24.vehicle',
    ),
    451 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '6e75d27fd62c37ef0d31927af48f5f65',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/a942792f82032957bb65643fb748fdcd.vehicle',
    ),
    452 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '954320d55a297b637e4423b6c76535c8',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/467955ab674a9c30a9b84d5e28bd12c1.vehicle',
    ),
    453 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '0e588ee1699d4d87cb66307d1b503947',
      'native_key' => 1,
      'filename' => 'modAccessPolicy/fa22eee407aa0e43c28f63736a0f9182.vehicle',
    ),
    454 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'd0962461fb2a4b55c2b1bcf818283264',
      'native_key' => 2,
      'filename' => 'modAccessPolicy/e52a34b454ceb570aabbc2ed247136c2.vehicle',
    ),
    455 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '4af64f78137f3d353945541b47c7cf1c',
      'native_key' => 3,
      'filename' => 'modAccessPolicy/bb3f002aab62f082dc38884e7aab199c.vehicle',
    ),
    456 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '2959b975dbca1cc7e7934c910d6a5059',
      'native_key' => 4,
      'filename' => 'modAccessPolicy/aa62bdfb1e52a650d2bffb30758a37ed.vehicle',
    ),
    457 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'd181288d4cea16c1a222a384101df542',
      'native_key' => 5,
      'filename' => 'modAccessPolicy/a27afaef876096bd2bc4fafd0d9196a9.vehicle',
    ),
    458 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'c6eb2bc1eb2d55a5df6e8374c1049f2c',
      'native_key' => 6,
      'filename' => 'modAccessPolicy/1fc4413c26854fda19359241656541d0.vehicle',
    ),
    459 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'd59777f2def03c5c3acbdc8b864cc132',
      'native_key' => 7,
      'filename' => 'modAccessPolicy/1aa9d10fbefe64f459cc7768003f82b5.vehicle',
    ),
    460 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '119e9c8e8b6b7c510fcc2cc2e1ad252f',
      'native_key' => 8,
      'filename' => 'modAccessPolicy/734628a538445cefabb5cdd1e97dc7df.vehicle',
    ),
    461 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'f31912df6cc49b967f37aba29db30798',
      'native_key' => 9,
      'filename' => 'modAccessPolicy/0eb97448d5c419fd51454a85b9707610.vehicle',
    ),
    462 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'cbf00ffb97abe6604a0c87c6bee4e55e',
      'native_key' => 10,
      'filename' => 'modAccessPolicy/05fc3a6225120be90ff8c27b87f86487.vehicle',
    ),
    463 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'f0865e2dd1857d8003e375045f8f1b10',
      'native_key' => 11,
      'filename' => 'modAccessPolicy/01fb27436b33778e07ceda8046f95dfd.vehicle',
    ),
    464 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '2845092697b59dd0fb38cd90bc7d065a',
      'native_key' => 12,
      'filename' => 'modAccessPolicy/9990937e3c4704461a65cfc107871220.vehicle',
    ),
    465 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => '9389668c1e832ffd4bedf8dca9e18884',
      'native_key' => 'web',
      'filename' => 'modContext/ab9c7d5d8fb0cd14c9b615ff69bbcf3a.vehicle',
    ),
    466 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => 'f832581f65ec9134033c41106d540dee',
      'native_key' => 'mgr',
      'filename' => 'modContext/61274fabfa9b8299843a2df060250654.vehicle',
    ),
    467 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'e2e8bc5f9cce6643a52dd9c19119ccf6',
      'native_key' => 'e2e8bc5f9cce6643a52dd9c19119ccf6',
      'filename' => 'xPDOFileVehicle/40217aff2b50685cc7d90958df78ca16.vehicle',
    ),
    468 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '471dfa0966ebb59ccf7d824c6fd77c4f',
      'native_key' => '471dfa0966ebb59ccf7d824c6fd77c4f',
      'filename' => 'xPDOFileVehicle/a5a91bd010cc244459de477ea5769987.vehicle',
    ),
    469 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'd1d81a631674e4a4c5bbe107fc3591b6',
      'native_key' => 'd1d81a631674e4a4c5bbe107fc3591b6',
      'filename' => 'xPDOFileVehicle/a5c62955373a48695cc04089bb26c4d6.vehicle',
    ),
    470 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '1fbd94db0e1efacec60996a64e2c01c7',
      'native_key' => '1fbd94db0e1efacec60996a64e2c01c7',
      'filename' => 'xPDOFileVehicle/6fffb2d95186a85842d9683431fc6066.vehicle',
    ),
  ),
);