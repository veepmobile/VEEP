package ru.ipartner.veep.app.dialog;

import android.app.Dialog;
import android.content.Context;

/**
 * Created by andrey on 09.12.2015.
 * @deprecated не используем
 */
public class MyAlertDialog extends Dialog {

    public MyAlertDialog(Context context) {
        super(context);
    }

    public MyAlertDialog(Context context, int themeResId) {
        super(context, themeResId);
    }

    public MyAlertDialog(Context context, boolean cancelable, OnCancelListener cancelListener) {
        super(context, cancelable, cancelListener);
    }

}
