package ru.ipartner.veep.app.model;

/**
 * тестовая модель
 * Created by andrey on 09.12.2015.
 */
public class History {
    public String date = "21.11.15 15:20";
    public String table = "3";
    public String officiant = "Константин Сидоров";
    public String sum = "20000";
    public String tips = "100%";
}
