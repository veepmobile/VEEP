package ru.ipartner.veep.app.activity;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import com.Wsdl2Code.WebServices.Rest.Personal;
import com.Wsdl2Code.WebServices.Rest.Profile;
import ru.ipartner.veep.app.Controller;
import ru.ipartner.veep.app.MainActivity;
import ru.ipartner.veep.app.R;

import java.io.IOException;
import java.net.SocketException;

/**
 *
 * Created by andrey on 09.12.2015.
 */
public class LoginActivity extends BaseActivity {
    private final static String TAG = LoginActivity.class.toString();

    private TextView enter;
    private EditText login;
    private EditText password;
    private TextView error;
    private TextView remind;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_login);

        enter = (TextView) findViewById(R.id.textViewEnter);
        login = (EditText) findViewById(R.id.editTextLogin);
        password = (EditText) findViewById(R.id.editTextPassword);
        error = (TextView) findViewById(R.id.textViewError);
        remind = (TextView) findViewById(R.id.textViewRemind);


        login.setText("");
        password.setText("");
        error.setVisibility(View.INVISIBLE);

        enter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new PersonalLoginAsync().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR);
            }
        });

        remind.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new PswRememberAsync().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR);
            }
        });
    }

    private class PersonalLoginAsync extends AsyncTask<Void, Void, Personal>{
        private Exception exception = null;

        @Override
        protected void onPreExecute() {
            showWaitDialog();
            error.setVisibility(View.INVISIBLE);
        }

        @Override
        protected void onPostExecute(Personal personal) {
            hideWaitDialog();
            if(personal == null && exception != null){
                if(exception instanceof SocketException){
                    showToast("Проблемы со связью. Проверьте подключение к интернет");
                }
                else{
                    showToast(exception.getMessage());
                }
            }
            else if(personal == null && exception == null){
                error.setVisibility(View.VISIBLE);
                password.setText("");
            }
            else {
                Controller.getInstance().setPersonal(personal);
                GetProfileAsync task = new GetProfileAsync();
                task.executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, personal);
            }
        }

        @Override
        protected Personal doInBackground(Void... params) {
            try {
                return rest.PersonalLogin(login.getText().toString(), password.getText().toString());
            } catch (IOException e) {
                exception = e;
                Log.w(TAG, e.getMessage());
                return null;
            }
        }
    }

    private class GetProfileAsync extends AsyncTask<Personal, Void, Profile>{
        @Override
        protected void onPreExecute() {
            showWaitDialog();
        }

        @Override
        protected Profile doInBackground(Personal... params) {
            Personal p = params[0];
            return rest.GetProfile(p.restaurantID, true);
        }

        @Override
        protected void onPostExecute(Profile profile) {
            hideWaitDialog();
            if(profile == null){
                Log.w(TAG, "get profile is null, maybe error on server?");
                showToast("get profile is null, maybe error on server?");
            }
            else{
                Controller.getInstance().setProfile(profile);
                Intent i = new Intent(LoginActivity.this, MainActivity.class);
                i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(i);
            }
        }
    }

    private class PswRememberAsync extends AsyncTask<Void, Void, Integer>{
        @Override
        protected void onPreExecute() {
            showWaitDialog();
        }

        @Override
        protected Integer doInBackground(Void... params) {
            return rest.PswRemember(login.getText().toString());
        }

        @Override
        protected void onPostExecute(Integer integer) {
            hideWaitDialog();
            String[] responses = getResources().getStringArray(R.array.remind_response);
            if(integer > responses.length){
                Log.w(TAG, "server return wrong data");
                showToast("server return wrong data");
            }
            else{
                String response = responses[integer];
                showToast(response);
            }
        }
    }
}
