package ru.ipartner.veep.app.receivers;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import ru.ipartner.veep.app.Controller;

/**
 *
 * Created by andrey on 09.02.2016.
 */
public class ConnectionReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        if(Controller.getInstance().isOnline()){
            //todo do something
        }
    }
}
