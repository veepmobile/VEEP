package ru.ipartner.veep.app.helpers;

import android.content.Context;
import android.os.PowerManager;
import android.util.Log;
import ru.ipartner.veep.app.Consts;
import ru.ipartner.veep.app.VeepApplication;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

/**
 *
 * Created by andrey on 09.02.2016.
 */
public class Helper {
    private final static String TAG = Helper.class.toString();

    public static PowerManager.WakeLock wakeLock(String tag, boolean partial){
        Log.d(TAG, "wakeLock");
        PowerManager powerManager = (PowerManager) VeepApplication.getContext().getSystemService(Context.POWER_SERVICE);
        PowerManager.WakeLock wakeLock = powerManager.newWakeLock(partial ? PowerManager.PARTIAL_WAKE_LOCK : PowerManager.FULL_WAKE_LOCK,
                tag);
        wakeLock.acquire();
        return wakeLock;
    }

    /**
     * 2016-02-09T20:06:51.853 to Date class
     * Берет время из C#, думает что это москва без милисекунд и возвращает правильный Date
     *
     * @param date yyyy-MM-ddThh:mm:ss.SSS
     * @return date from C# string date
     */
    public static Date sharpDateToJavaDate(String date){
        try {
            date = date.substring(0,19) + " " + Consts.Time.SERVER_TIME_OFFSET;
        } catch (Exception e) {
            return new Date();
        }
        //SimpleDateFormat dateFormat = new SimpleDateFormat(date.length() == 23 ? "yyyy-MM-dd'T'hh:mm:ss.SSS Z" : "yyyy-MM-dd'T'hh:mm:ss Z");
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss Z");
        dateFormat.setTimeZone(TimeZone.getTimeZone(Consts.Time.CLIENT_TIME_ZONE));
        try {
            return dateFormat.parse(date/*.replace("T", " ")*/);
        } catch (ParseException e) {
            e.printStackTrace();
            return new Date();
            //return null;
        }
    }

    /*public static String millisToTime(long millis){
        long sec = Math.abs(millis / 1000);
    }*/
}
