package ru.ipartner.veep.app.fragment;

import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import com.Wsdl2Code.WebServices.Rest.HistoryPayments;
import ru.ipartner.veep.app.Consts;
import ru.ipartner.veep.app.Controller;
import ru.ipartner.veep.app.R;
import ru.ipartner.veep.app.helpers.Helper;
import ru.ipartner.veep.app.model.History;

import java.text.SimpleDateFormat;
import java.util.*;

/**
 *
 * Created by andrey on 09.12.2015.
 */
public class HistoryFragment extends BaseFragment {
    private final static String TAG = HistoryFragment.class.toString();

    //UI
    private ListView listView;

    private final HistoryAdapter adapter = new HistoryAdapter();

    private Timer updateTimer;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        View v = inflater.inflate(R.layout.fragment_history, container, false);

        listView = (ListView) v.findViewById(R.id.listView);
        listView.setAdapter(adapter);

        if(updateTimer != null) updateTimer.cancel();
        updateTimer = new Timer();
        updateTimer.schedule(new UpdateTask(), 0, Consts.UPDATE_INTERVAL);

        return v;
    }

    private class UpdateTask extends TimerTask {
        @Override
        public void run() {
            Log.d(TAG, "UpdateTask");
            if(Controller.getInstance().isOnline()){
                GetHistoryPaymentsAsync task = new GetHistoryPaymentsAsync();
                task.executeOnExecutor(AsyncTask.SERIAL_EXECUTOR);
            }
            else{
                Log.w(TAG, "no internet connection");
                showToast(R.string.error_no_internet);
            }
        }
    }

    @Override
    public void onDestroyView() {
        if(updateTimer != null) updateTimer.cancel();
        updateTimer = null;

        super.onDestroyView();
    }

    private class HistoryAdapterTest extends BaseAdapter{
        final List<History> histories = new ArrayList<>();

        @Override
        public int getCount() {
            return histories.size();
        }

        @Override
        public Object getItem(int position) {
            return histories.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        public void addItem(History history){
            histories.add(0, history);
            notifyDataSetChanged();
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            LinearLayout layout = (LinearLayout)LinearLayout.inflate(getActivity(), R.layout.history_item, null);

            boolean odd = position % 2 == 1;

            if(odd) layout.setBackgroundResource(R.color.app_gray_light);

            return layout;
        }
    }

    private class HistoryAdapter extends BaseAdapter{
        private List<HistoryPayments> paymentses = new ArrayList<>();

        @Override
        public int getCount() {
            return paymentses.size();
        }

        @Override
        public Object getItem(int position) {
            return paymentses.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            LinearLayout layout = (LinearLayout)LinearLayout.inflate(getActivity(), R.layout.history_item, null);

            TextView date = (TextView)layout.findViewById(R.id.textViewDate);
            TextView table = (TextView)layout.findViewById(R.id.textViewTable);
            TextView name = (TextView)layout.findViewById(R.id.textViewName);
            TextView tips = (TextView)layout.findViewById(R.id.textViewTips);
            TextView sum = (TextView)layout.findViewById(R.id.textViewSum);

            HistoryPayments hp = paymentses.get(position);

            SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yy HH:mm");
            dateFormat.setTimeZone(TimeZone.getTimeZone(Consts.Time.CLIENT_TIME_ZONE));
            date.setText(dateFormat.format(Helper.sharpDateToJavaDate(hp.paymentDate)));
            table.setText(hp.tableID);
            name.setText(hp.waiterName);
            //tips.setText(Math.round(hp.tippingSum) + "%");
            tips.setText(Long.toString(Math.round(hp.tippingSum)));
            sum.setText(Math.round(hp.orderSum) + "");

            boolean odd = position % 2 == 1;

            if(odd) layout.setBackgroundResource(R.color.app_gray_light);

            return layout;
        }

        public void setPaymentses(List<HistoryPayments> paymentses) {
            if(paymentses == null) paymentses = new ArrayList<>();
            this.paymentses = paymentses;
            notifyDataSetChanged();
        }
    }

    private class GetHistoryPaymentsAsync extends AsyncTask<Void, Void, List<HistoryPayments>>{
        @Override
        protected void onPreExecute() {
            Log.d(TAG, "GetHistoryPaymentsAsync.onPreExecute");
        }

        @Override
        protected List<HistoryPayments> doInBackground(Void... params) {
            Log.d(TAG, "GetHistoryPaymentsAsync.doInBackground");
            if(Controller.getInstance().getProfile() == null) return null;   //TODO !!!
            return Controller.getInstance().getRest().GetHistoryPayments(Controller.getInstance().getProfile().restaurantID, true);
        }

        @Override
        protected void onPostExecute(List<HistoryPayments> historyPaymentses) {
            Log.d(TAG, "GetHistoryPaymentsAsync.onPostExecute");
            adapter.setPaymentses(historyPaymentses);
        }
    }
}
