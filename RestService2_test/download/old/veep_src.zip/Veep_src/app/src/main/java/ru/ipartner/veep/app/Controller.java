package ru.ipartner.veep.app;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.support.annotation.Nullable;
import com.Wsdl2Code.WebServices.Rest.Personal;
import com.Wsdl2Code.WebServices.Rest.Profile;
import com.Wsdl2Code.WebServices.Rest.Rest;

/**
 *
 * Created by andrey on 08.02.2016.
 */
public class Controller {
    private static final Controller instance = new Controller();
    private Personal personal;  //current personal
    private Profile profile;    //профиль ресторана

    private Rest rest;

    public static Controller getInstance() {
        return instance;
    }

    /**
     *
     * @return may be null
     */
    @Nullable
    public Personal getPersonal() {
        return personal;
    }

    public void setPersonal(Personal personal) {
        this.personal = personal;
    }

    /**
     *
     * @return may be null
     */
    @Nullable
    public Profile getProfile() {
        return profile;
    }

    public void setProfile(Profile profile) {
        this.profile = profile;
    }

    public Rest getRest() {
        return rest;
    }

    public void setRest(Rest rest) {
        this.rest = rest;
    }

    public boolean isAdmin(){
        if(getPersonal() == null) return false;
        return getPersonal().rolesID == Consts.Roles.ADMIN;
    }

    public boolean isOnline(){
        Context context = VeepApplication.getContext();
        ConnectivityManager connectivityManager = (ConnectivityManager)
                context.getSystemService(Context.CONNECTIVITY_SERVICE );
        NetworkInfo netInfo = connectivityManager.getActiveNetworkInfo();
        return netInfo != null && netInfo.isConnectedOrConnecting();
    }
}
