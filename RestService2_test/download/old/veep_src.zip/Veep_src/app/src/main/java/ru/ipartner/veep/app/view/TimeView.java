package ru.ipartner.veep.app.view;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.TextView;
import ru.ipartner.veep.app.Consts;

import java.text.SimpleDateFormat;
import java.util.*;

/**
 * тупо часики
 * Created by andrey on 09.12.2015.
 */
public class TimeView extends TextView {
    private Timer timer;
    private MyTimerTask timerTask;

    private static final String TIME1 = "HH:mm";
    private static final String TIME2 = "HH mm";

    private AttributeSet attributeSet;

    public TimeView(Context context) {
        this(context, null);
    }

    public TimeView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public TimeView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);

        this.attributeSet = attrs;
        build();
    }

    private void build(){
        timer = new Timer();
        timerTask = new MyTimerTask();

        timer.schedule(timerTask, 1000, 1000);
    }

    private static final boolean dots = true;

    class MyTimerTask extends TimerTask {
        @Override
        public void run() {
            //dots = !dots;
            Calendar calendar = Calendar.getInstance();
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat(
                    //"dd:MMMM:yyyy HH:mm:ss a", Locale.getDefault());  //default
                    dots ? TIME1 : TIME2, Locale.getDefault());                      //work
                    //"mm:ss", Locale.getDefault());                    //for test
            Date d = calendar.getTime();
            simpleDateFormat.setTimeZone(TimeZone.getTimeZone(Consts.Time.CLIENT_TIME_ZONE));
            final String strDate = simpleDateFormat.format(d);

            post(new Runnable() {
                @Override
                public void run() {
                    setText(strDate);
                }
            });
        }
    }
}
