package ru.ipartner.veep.app;

import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Intent;
import android.os.Bundle;
import android.os.PowerManager;
import android.support.v4.widget.DrawerLayout;
import android.util.Log;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import ru.ipartner.veep.app.activity.BaseActivity;
import ru.ipartner.veep.app.activity.ControlActivity;
import ru.ipartner.veep.app.activity.LoginActivity;
import ru.ipartner.veep.app.fragment.HistoryFragment;
import ru.ipartner.veep.app.fragment.MessagesFragment;
import ru.ipartner.veep.app.helpers.Helper;
import ru.ipartner.veep.app.view.DrawerView;
import ru.ipartner.veep.app.view.ToolbarView;


public class MainActivity extends BaseActivity {
    private final static String TAG = MainActivity.class.toString();
    private PowerManager.WakeLock wakeLock;

    private DrawerView drawer;
    private ToolbarView toolbar;
    private FrameLayout fragment;

    private DrawerLayout mDrawerLayout;
    private LinearLayout drawerItem1;
    private LinearLayout drawerItem2;

    FragmentManager fragmentManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d(TAG, "onCreate");

        setContentView(R.layout.activity_main);

        wakeLock = Helper.wakeLock(TAG, false);

        drawer = (DrawerView) findViewById(R.id.drawer);
        drawerItem1 = (LinearLayout) findViewById(R.id.drawerItem1);
        drawerItem2 = (LinearLayout) findViewById(R.id.drawerItem2);
        toolbar = (ToolbarView) findViewById(R.id.toolbar);
        fragment = (FrameLayout) findViewById(R.id.fragment);
        mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);

        toolbar.setIconClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                drawer.show();
                mDrawerLayout.openDrawer(drawer);
            }
        });

        fragment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                drawer.hide();
            }
        });

        toolbar.setTabClickedListener(new ToolbarView.OnTabClickedListener() {
            @Override
            public void onClick(int tab) {
                if(tab == 0){
                    showMessages();
                }
                else{
                    if(Controller.getInstance().isAdmin()) showHistory();
                }
            }
        });

        if(!Controller.getInstance().isAdmin()){
            drawerItem1.setVisibility(View.GONE);
        }

        drawerItem1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                drawer.hide();
                mDrawerLayout.closeDrawer(drawer);
                Intent i = new Intent(MainActivity.this, ControlActivity.class);
                startActivity(i);
            }
        });

        drawerItem2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mDrawerLayout.closeDrawer(drawer);
                startLoginActivity();
                //onBackPressed();
            }
        });

        fragmentManager = getFragmentManager();

        showMessages();
    }

    @Override
    protected void onResume() {
        super.onResume();

        if(Controller.getInstance().getPersonal() == null || Controller.getInstance().getProfile() == null)
            startLoginActivity();   //уйти на экран логина, если по какой то причине произошло разлогинивание
    }

    private void startLoginActivity(){
        Intent i = new Intent(MainActivity.this, LoginActivity.class);
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(i);
    }

    @Override
    protected void onDestroy() {
        Log.d(TAG, "onDestroy");
        wakeLock.release();
        super.onDestroy();
    }

    private void showMessages(){
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        MessagesFragment fragment = new MessagesFragment();
        fragmentTransaction.replace(R.id.fragment, fragment);
        fragmentTransaction.commit();
    }

    private void showHistory(){
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        HistoryFragment fragment = new HistoryFragment();
        fragmentTransaction.replace(R.id.fragment, fragment);
        fragmentTransaction.commit();
    }
}
