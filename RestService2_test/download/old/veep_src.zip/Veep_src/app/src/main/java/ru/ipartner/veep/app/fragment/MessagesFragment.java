package ru.ipartner.veep.app.fragment;

import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Toast;
import com.Wsdl2Code.WebServices.Rest.Messages;
import ru.ipartner.veep.app.Consts;
import ru.ipartner.veep.app.Controller;
import ru.ipartner.veep.app.R;
import ru.ipartner.veep.app.helpers.Helper;
import ru.ipartner.veep.app.view.MessageView;
import ru.ipartner.veep.app.view.RelativeTimeView;

import java.util.*;

/**
 *
 * Created by andrey on 09.12.2015.
 */
public class MessagesFragment extends BaseFragment {
    private static final String TAG = MessagesFragment.class.toString();

    private ListView listView;
    private ListView listViewAdmin;
    private LinearLayout linearLayoutAdmin;

    private final MessageAdapter adapter = new MessageAdapter(false);
    private final MessageAdapter adapterAdmin = new MessageAdapter(true);

    private Timer updateTimer;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        View v = inflater.inflate(R.layout.fragment_messages, container, false);

        linearLayoutAdmin = (LinearLayout) v.findViewById(R.id.linearLayoutAdmin);
        listView = (ListView) v.findViewById(R.id.listView);
        listViewAdmin = (ListView) v.findViewById(R.id.listView2);

        //if(!Controller.getInstance().isAdmin()) linearLayoutAdmin.setVisibility(View.GONE);

        listView.setAdapter(adapter);
        listViewAdmin.setAdapter(adapterAdmin);

//        GetMessagesAsync task1 = new GetMessagesAsync();
//        task1.executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, Consts.MessagesMode.GENERAL);
//        GetMessagesAsync task2 = new GetMessagesAsync();
//        task2.executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, Consts.MessagesMode.OTHER);

        if(updateTimer != null) updateTimer.cancel();
        updateTimer = new Timer();
        updateTimer.schedule(new UpdateTask(), 0, Consts.UPDATE_INTERVAL);

        return v;
    }

    private class UpdateTask extends TimerTask{
        @Override
        public void run() {
            Log.d(TAG, "UpdateTask");
            if(Controller.getInstance().isOnline()){
                GetMessagesAsync task1 = new GetMessagesAsync();
                task1.executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, Consts.MessagesMode.GENERAL);
                GetMessagesAsync task2 = new GetMessagesAsync();
                task2.executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, Consts.MessagesMode.OTHER);
            }
            else{
                Log.w(TAG, "no internet connection");
                if(MessagesFragment.this.isAdded() && getActivity() != null){
                    getActivity().runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(getActivity(), R.string.error_no_internet, Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            }
        }
    }

    @Override
    public void onDestroyView() {
        if(updateTimer != null) updateTimer.cancel();
        updateTimer = null;

        super.onDestroyView();
    }

    @Override
    public void onDestroy() {
        Log.d(TAG, "onDestroy");

        RelativeTimeView.cancelAll();

        super.onDestroy();
    }

    private class MessageAdapter extends BaseAdapter{
        private boolean other = false;  //основные или дополнительные сообщения
        private List<Messages> messages = new ArrayList<>();

        public MessageAdapter(boolean other) {
            this.other = other;
        }

        @Override
        public int getCount() {
            return messages.size();
        }

        @Override
        public Object getItem(int position) {
            return messages.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        public void removeMessage(int messageID){
            Messages message = null;
            for(Messages m : messages){
                if(m.iD == messageID){
                    message = m;
                    break;
                }
            }
            if(message == null) return;
            //cancel timer task for message
            /* Канцелить таймеры не надо, так как их всего 11 штук на экран выходит, они "повторяют функционал"*/
            messages.remove(message);
            notifyDataSetChanged();
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            MessageView mv;
            if(convertView == null)
                mv = new MessageView(getActivity());
            else
                mv = (MessageView)convertView;

            final Messages m = messages.get(position);

            if(other){
                mv.setType(MessageView.Type.ADMIN);
            }
            else{
                switch (m.messageType){
                    case Consts.MessageGeneralType.CALL:
                    //case Consts.MessageGeneralType.PAID:
                        mv.setType(MessageView.Type.GREEN);
                        break;
                    case Consts.MessageGeneralType.CANCEL:
                    case Consts.MessageGeneralType.ERROR:
                    case Consts.MessageGeneralType.PAID_ERROR:
                        mv.setType(MessageView.Type.RED);
                        break;
                    case Consts.MessageGeneralType.BILL:
                        mv.setType(MessageView.Type.YELLOW);
                        break;
                }
                mv.setOkClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if(Controller.getInstance().getPersonal() == null) return;   //TODO !!!
                        ReadMessageAsync task = new ReadMessageAsync(m.iD, Controller.getInstance().getPersonal().iD);
                        task.executeOnExecutor(AsyncTask.SERIAL_EXECUTOR);
                    }
                });
            }

            mv.setText(m.messageText);
            mv.setTable(m.tableID);
            Date parsedDate = Helper.sharpDateToJavaDate(m.messageDate);
            mv.setTime(parsedDate.getTime());
            mv.update();    //обновить ?? лишшний метод
            mv.updateUI();
            return mv;
        }

        public void setMessages(List<Messages> messages) {
            if(messages == null) messages = new ArrayList<>();
            Collections.sort(messages, new Comparator<Messages>() {
                @Override
                public int compare(Messages lhs, Messages rhs) {
                    return rhs.messageDate.compareTo(lhs.messageDate);
                }
            });
            this.messages = messages;
            notifyDataSetChanged();
        }
    }

    private class GetMessagesAsync extends AsyncTask<Integer, Void, List<Messages>>{
        private int mode;
        @Override
        protected void onPreExecute() {
            Log.d(TAG, "GetMessagesAsync.onPreExecute");
        }

        @Override
        protected List<Messages> doInBackground(Integer... params) {
            Log.d(TAG, "GetMessagesAsync.doInBackground");
            mode = params[0];
            //if(mode == Consts.MessagesMode.OTHER && !Controller.getInstance().isAdmin()) return new ArrayList<>();
            if(Controller.getInstance().getProfile() == null) return null;   //TODO !!!
            return Controller.getInstance().getRest().GetMessages(Controller.getInstance().getProfile().restaurantID, true, mode, true);
        }

        @Override
        protected void onPostExecute(List<Messages> messages) {
            Log.d(TAG, "GetMessagesAsync.onPostExecute");
            // TODO remove switch on future if needed
            switch (mode){
                case Consts.MessagesMode.GENERAL:
                    adapter.setMessages(messages);
                    break;
                case Consts.MessagesMode.OTHER:
                    /*if(Controller.getInstance().isAdmin())*/ adapterAdmin.setMessages(messages);
                    break;
            }
        }
    }

    private class ReadMessageAsync extends AsyncTask<Void, Void, Integer>{
        private final int messageID;
        private final int personalID;

        public ReadMessageAsync(int messageID, int personalID) {
            this.messageID = messageID;
            this.personalID = personalID;
        }

        @Override
        protected Integer doInBackground(Void... params) {
            return Controller.getInstance().getRest().ReadMessage(messageID, true, personalID, true);
        }

        @Override
        protected void onPostExecute(Integer integer) {
            if(integer == null){
                Log.w(TAG, "error on ReadMessage");
                showToast("error on ReadMessage");
            }
            else{
                if(integer == Consts.Responses.FAIL){
                    Log.w(TAG, "FAIL on ReadMessage");
                    showToast("FAIL on ReadMessage");
                }
                else{
                    adapter.removeMessage(messageID);
                    Toast.makeText(getActivity(), "Ok", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }
}
