package ru.ipartner.veep.app;

/**
 *
 * Created by andrey on 08.02.2016.
 */
public class Consts {
    public final static int REST_TIMEOUT = 60;
    public final static String REST_ENDPOINT = "http://185.26.113.204/Rest.svc/soap";
    public final static int UPDATE_INTERVAL = 5000;

    public class Time{
        public static final String SERVER_TIME_OFFSET = "+0300";
        public static final String CLIENT_TIME_ZONE = "Europe/Moscow";
    }

    public class Roles{
        public static final int ADMIN = 1;
        public static final int OFFICIANT = 2;
    }

    public class MessagesMode{
        public static final int GENERAL = 1;
        public static final int OTHER = 2;
    }

    public class MessageGeneralType{
        public static final int CALL = 1;   //вызов официанта
        public static final int BILL = 2;   //принести счет,
        public static final int CANCEL = 3; //отмена счета,
        public static final int PAID_ERROR = 4; //отмена счета,
        public static final int ERROR = 10; //ошибка в кассовом ПО
    }

    public class MessageOtherType{
        public static final int PAID = 8;   //заказ оплачен,
        public static final int AUTH = 101;     //авторизация пользователя,
        public static final int START = 102;    //начало оплаты заказа.
    }

    public class Responses{
        public final static int OK = 1;
        public final static int FAIL = 0;
    }
}
