package ru.ipartner.veep.app.model;

/**
 *
 * Created by andrey on 09.12.2015.
 */
public class Message {
    public static final int TYPE_CALL = 0;
    public static final int TYPE_PAY = 1;
    public static final int TYPE_BRING = 2;
    public static final int TYPE_ADMIN = 3;

    public int type = 0;
    public long time = 0;
    public String text = "";
    public String table = "11";

    public Message(int type) {
        time = System.currentTimeMillis();
        this.type = type;
        //this.type = ((int)(Math.random() * 10000)) % 3;

        switch (type){
            case TYPE_BRING:
                text = "ПРИНЕСТИ СЧЕТ";
                break;
            case TYPE_PAY:
                text = "ЗАКАЗ ОПЛАЧЕН (10%)";
                break;
            case TYPE_CALL:
                text = "ВЫЗОВ ОФИЦИАНТА";
            case TYPE_ADMIN:
                text = "НАЧАЛО ОПЛАТЫ";
                break;
        }
    }

    boolean ret(){
        return true;
    }
}
