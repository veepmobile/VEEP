package ru.ipartner.veep.app.fragment;

import android.app.Fragment;
import android.widget.Toast;

/**
 *
 * Created by andrey on 09.02.2016.
 */
public class BaseFragment extends Fragment {
    protected void showToast(final int res){
        if(isAdded() && getActivity() != null){
            getActivity().runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    String message = getActivity().getResources().getString(res);
                    Toast.makeText(getActivity(), message, Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    protected void showToast(final String message){
        if(isAdded() && getActivity() != null){
            getActivity().runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(getActivity(), message, Toast.LENGTH_SHORT).show();
                }
            });
        }
    }
}
