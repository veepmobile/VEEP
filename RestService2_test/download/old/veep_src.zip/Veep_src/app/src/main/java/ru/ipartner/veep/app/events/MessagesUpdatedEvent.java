package ru.ipartner.veep.app.events;

/**
 *
 * Created by andrey on 09.02.2016.
 */
public class MessagesUpdatedEvent {
}
