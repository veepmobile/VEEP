package ru.ipartner.veep.app.activity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ProgressDialog;
import android.os.Bundle;
import android.widget.Toast;
import com.Wsdl2Code.WebServices.Rest.Rest;
import ru.ipartner.veep.app.Consts;
import ru.ipartner.veep.app.Controller;
import ru.ipartner.veep.app.R;

/**
 *
 * Created by andrey on 08.02.2016.
 */
@SuppressLint("Registered")
public class BaseActivity extends Activity {
    protected Rest rest;

    ProgressDialog progress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        rest = new Rest();
        rest.setUrl(Consts.REST_ENDPOINT);
        rest.setTimeOut(Consts.REST_TIMEOUT);
        Controller.getInstance().setRest(rest);
    }

    protected void showWaitDialog(){
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if(progress == null)
                    progress = ProgressDialog.show(BaseActivity.this, getResources().getString(R.string.wait_title),
                            getResources().getString(R.string.wait_text), true);
            }
        });
    }

    protected void hideWaitDialog(){
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if(progress != null)
                    progress.dismiss();
                progress = null;
            }
        });
    }

    protected void showToast(String message){
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}
