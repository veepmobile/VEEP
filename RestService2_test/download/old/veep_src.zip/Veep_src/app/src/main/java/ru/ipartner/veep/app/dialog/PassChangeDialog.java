package ru.ipartner.veep.app.dialog;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import ru.ipartner.veep.app.Controller;
import ru.ipartner.veep.app.R;

/**
 *
 * Created by Aand1rey on 09.12.2015.
 */
public class PassChangeDialog extends Dialog {
    private final static String TAG = PassChangeDialog.class.toString();

    private EditText password;
    private EditText new1;
    private EditText new2;
    private TextView ok;
    private TextView cancel;

    private OnClick listener;

    public PassChangeDialog(Context context) {
        super(context);
    }

    public PassChangeDialog(Context context, int themeResId) {
        super(context, themeResId);
    }

    public PassChangeDialog(Context context, boolean cancelable, OnCancelListener cancelListener) {
        super(context, cancelable, cancelListener);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        requestWindowFeature(Window.FEATURE_NO_TITLE);

        setContentView(R.layout.dialog_pass_change);
        password = (EditText) findViewById(R.id.editTextPassword);
        new1 = (EditText) findViewById(R.id.editTextNew1);
        new2 = (EditText) findViewById(R.id.editTextNew2);
        ok = (TextView) findViewById(R.id.ok);
        cancel = (TextView) findViewById(R.id.cancel);

        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(Controller.getInstance().getProfile() == null) return;   //TODO !!!
                if(!Controller.getInstance().getProfile().adminPsw.equals(password.getText().toString())){
                    Log.w(TAG, "current password wrong");
                    Toast.makeText(getContext(), R.string.error_wrong_password, Toast.LENGTH_SHORT).show();
                    return;
                }

                boolean result = !new1.getText().toString().equals("") && new1.getText().equals(new2.getText());
                if(result){
                    if(listener != null) listener.onClick(true, new1.getText().toString());
                    dismiss();
                }
                else{
                    Toast.makeText(getContext(), R.string.error_passwords_not_equals, Toast.LENGTH_SHORT).show();
                }
            }
        });

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(listener != null) listener.onClick(false, "");
                dismiss();
            }
        });
    }

    public void setListener(OnClick listener) {
        this.listener = listener;
    }

    public interface OnClick{
        public void onClick(boolean ok, String pass);
    }
}
