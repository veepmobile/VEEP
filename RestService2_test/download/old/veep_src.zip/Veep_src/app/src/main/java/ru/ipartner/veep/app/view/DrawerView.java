package ru.ipartner.veep.app.view;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import ru.ipartner.veep.app.R;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * Created by andrey on 09.12.2015.
 */
public class DrawerView extends LinearLayout {
    private boolean isHidden = false;
    private final List<Item> items = new ArrayList<>();

    public DrawerView(Context context) {
        this(context, null);
    }

    public DrawerView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public DrawerView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);

        build(attrs);
    }

    private void build(AttributeSet attrs){
        setBackgroundResource(R.color.drawer_background);

        TypedArray a = getContext().getTheme().obtainStyledAttributes(
                attrs,
                R.styleable.DrawerView,
                0, 0);
        isHidden = a.getBoolean(R.styleable.DrawerView_hidden1, isHidden);

        if(isHidden)
            _hide();
        else
            _show();
    }

    public void addItem(Item item){
        items.add(item);

        addView(item.getView(getContext()));
    }

    private void _show(){
        setVisibility(VISIBLE);

        isHidden = false;
    }

    private void _hide(){
        setVisibility(GONE);

        isHidden = true;
    }

    public void show(){
        _show();
    }

    public void hide(){
        _hide();
    }

    public static class Item{
        private final String text;
        private final int icon;
        private final View.OnClickListener clickListener;

        //UI
        private TextView textView;

        public Item(String text, int icon, OnClickListener clickListener) {
            this.text = text;
            this.icon = icon;
            this.clickListener = clickListener;
        }

        public View getView(Context context){
            LinearLayout layout = (LinearLayout)LinearLayout.inflate(context, R.layout.item_drawer, null);

            textView = (TextView) layout.findViewById(R.id.textView);

            textView.setText(text);
            textView.setCompoundDrawables(context.getResources().getDrawable(icon), null, null, null);
            if(clickListener != null) textView.setOnClickListener(clickListener);

            return layout;
        }
    }
}
