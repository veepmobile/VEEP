package ru.ipartner.veep.app;

import android.app.Application;
import android.content.Context;
import org.acra.ACRA;
import org.acra.ReportingInteractionMode;
import org.acra.annotation.ReportsCrashes;

/**
 *
 * Created by andrey on 09.02.2016.
 */
@ReportsCrashes(
        formKey = "", // This is required for backward compatibility but not used
        formUri = "http://bnet.i-partner.ru/projects/ACRA/",
        mode = ReportingInteractionMode.TOAST,
        forceCloseDialogAfterToast = true,
        resToastText = R.string.crash_toast_text
)
public class VeepApplication extends Application {
    private static Context context;

    public static Context getContext() {
        return context;
    }

    @Override
    public void onCreate() {
        super.onCreate();

        context = getApplicationContext();

        //init!
        if(!BuildConfig.DEBUG) ACRA.init(this);
        //throw new RuntimeException("catch me!");
    }
}
