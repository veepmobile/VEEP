package ru.ipartner.veep.app.activity;

import android.os.AsyncTask;
import android.os.Bundle;
import android.telephony.PhoneNumberFormattingTextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import ru.ipartner.veep.app.Controller;
import ru.ipartner.veep.app.R;
import ru.ipartner.veep.app.dialog.ConfirmDialog;
import ru.ipartner.veep.app.dialog.PassChangeDialog;
import ru.ipartner.veep.app.view.ToolbarView;

/**
 *
 * Created by andrey on 09.12.2015.
 */
public class ControlActivity extends BaseActivity{
    private ToolbarView toolbar;
    private TextView login;
    private TextView login2;
    private EditText phone;
    private EditText password;
    private TextView apply;
    private TextView setPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_control);

        toolbar = (ToolbarView) findViewById(R.id.toolbar);
        login = (TextView) findViewById(R.id.textViewLogin);
        login2 = (TextView) findViewById(R.id.textViewLogin2);
        phone = (EditText) findViewById(R.id.editTextPhone);
        password = (EditText) findViewById(R.id.editTextPassword);
        apply = (TextView) findViewById(R.id.textViewApply);
        setPassword = (TextView) findViewById(R.id.textViewSetPassword);

        phone.addTextChangedListener(new PhoneNumberFormattingTextWatcher());
        toolbar.setIconClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        if(Controller.getInstance().getProfile() != null){
            login.setText(Controller.getInstance().getProfile().adminLogin);
            login2.setText(Controller.getInstance().getProfile().officiantLogin);
            phone.setText(Controller.getInstance().getProfile().phoneNumber);
            password.setText(Controller.getInstance().getProfile().officiantPsw);
        }

        apply.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final ConfirmDialog dialog = new ConfirmDialog(ControlActivity.this);
                dialog.setListener(new ConfirmDialog.OnClick() {
                    @Override
                    public void onClick(boolean ok) {
                        if(ok){
                            if(Controller.getInstance().getProfile() == null) return;   //TODO !!!
                            ChangePersonalPswAsync task = new ChangePersonalPswAsync(Controller.getInstance().getProfile().officiantID, password.getText().toString());
                            task.executeOnExecutor(AsyncTask.SERIAL_EXECUTOR);
                        }
                    }
                });
                dialog.show();
            }
        });

        setPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final PassChangeDialog dialog = new PassChangeDialog(ControlActivity.this);
                dialog.setListener(new PassChangeDialog.OnClick() {
                    @Override
                    public void onClick(boolean ok, String pass) {
                        if(ok){
                            if(Controller.getInstance().getProfile() == null) return;   //TODO !!!
                            ChangePersonalPswAsync task = new ChangePersonalPswAsync(Controller.getInstance().getProfile().adminID, password.getText().toString());
                            task.executeOnExecutor(AsyncTask.SERIAL_EXECUTOR);
                        }
                    }
                });
                dialog.show();
            }
        });
    }

    private class ChangePersonalPswAsync extends AsyncTask<Void, Void, Integer>{
        private final int personalID;
        private final String newPassword;

        public ChangePersonalPswAsync(int personalID, String newPassword) {
            this.personalID = personalID;
            this.newPassword = newPassword;
        }

        @Override
        protected void onPreExecute() {
            showWaitDialog();
        }

        @Override
        protected Integer doInBackground(Void... params) {
            return Controller.getInstance().getRest().ChangePersonalPsw(personalID, true, newPassword);
        }

        @Override
        protected void onPostExecute(Integer integer) {
            if(integer == null || integer != 1){
                Toast.makeText(ControlActivity.this, R.string.password_change_error, Toast.LENGTH_SHORT).show();
            }
            else{
                Toast.makeText(ControlActivity.this, R.string.password_changed, Toast.LENGTH_SHORT).show();
            }
            hideWaitDialog();
        }
    }
}
