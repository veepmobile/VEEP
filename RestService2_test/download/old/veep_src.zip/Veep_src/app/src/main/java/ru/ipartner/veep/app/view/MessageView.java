package ru.ipartner.veep.app.view;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import ru.ipartner.veep.app.R;

/**
 *
 * Created by andrey on 09.12.2015.
 */
public class MessageView extends FrameLayout {
    private TextView ok;
    private TextView text;
    private TextView table;
    private RelativeTimeView time;


    private FrameLayout frameButton;

    private boolean admin = false;

    private RelativeLayout layout;

    public enum Type{
        RED(R.color.app_message_red),
        GREEN(R.color.app_message_green),
        YELLOW(R.color.app_message_yellow),
        ADMIN(R.color.app_green_forest);

        final int resBack;

        Type(int resBack) {
            this.resBack = resBack;
        }
    }

    private Type type = Type.GREEN;

    private View.OnClickListener listener;

    public MessageView(Context context) {
        this(context, null);
    }

    public MessageView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public MessageView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);

        build(attrs);
    }

    private void build(AttributeSet attrs){
        FrameLayout frame = (FrameLayout)LayoutInflater.from(getContext()).inflate(R.layout.view_message, this);

        layout = (RelativeLayout) frame.findViewById(R.id.layout);
        frameButton = (FrameLayout) frame.findViewById(R.id.frameButton);
        ok = (TextView) frame.findViewById(R.id.ok);
        text = (TextView) frame.findViewById(R.id.textView);
        table = (TextView) frame.findViewById(R.id.textViewTable);
        time = (RelativeTimeView) frame.findViewById(R.id.relativeTimeView);

        ok.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if(listener != null) listener.onClick(v);
            }
        });

        updateUI();
    }

    public void setAdmin(boolean admin) {
        this.admin = admin;

        setType(Type.ADMIN);
    }

    public void updateUI(){
        if(layout != null){
            layout.setBackgroundResource(type.resBack);
        }

        if(admin){
            frameButton.setVisibility(GONE);
        }
    }

    public void update() {
        time.update();
    }

    public void setType(Type type){
        admin = type.equals(Type.ADMIN);
        this.type = type;
        updateUI();
    }

    public void setTime(long time) {
        this.time.setTime(time);
        //updateUI();
    }

    public void cancel(){
        time.cancel();
    }

    public void setText(String text){
        this.text.setText(text);
    }

    public void setTable(String table){
        this.table.setText(table);
    }

    public void setOkClickListener(View.OnClickListener listener){
        this.listener = listener;
    }
}
