package ru.ipartner.veep.app.view;

import android.content.Context;
import android.util.AttributeSet;
import android.util.Log;
import android.widget.TextView;
import ru.ipartner.veep.app.Consts;

import java.text.SimpleDateFormat;
import java.util.*;

/**
 *
 * Created by andrey on 09.12.2015.
 */
public class RelativeTimeView extends TextView{
    private final static String TAG = RelativeTimeView.class.toString();
    private final static String FORMAT = "%s (%s)";
    private long time = 0;
    public static final List<Timer> timers = new ArrayList<>(); //так как мы используем этот контрол только в FrameMessages, то будем насчадно убивать таймеры

    private Timer timer;
    private MyTimerTask timerTask;

    public RelativeTimeView(Context context) {
        this(context, null);
    }

    public RelativeTimeView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public RelativeTimeView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);

        build(attrs);
        Log.d(TAG, "timers: " + timers.size());
    }

    public void build(AttributeSet attrs){
        timer = new Timer();
        timerTask = new MyTimerTask();

        timer.schedule(timerTask, 0, 1000);
        setTime(System.currentTimeMillis());
    }

    /**
     * Установить время
     * @param time
     */
    public void setTime(long time) {
        this.time = time;
        _setTime();
    }

    protected synchronized void _setTime(){
        SimpleDateFormat hh_mm = new SimpleDateFormat(
                "HH:mm");
        SimpleDateFormat mm_ss = new SimpleDateFormat(
                "mm:ss");
        mm_ss.setTimeZone(TimeZone.getTimeZone(Consts.Time.CLIENT_TIME_ZONE));
        hh_mm.setTimeZone(TimeZone.getTimeZone(Consts.Time.CLIENT_TIME_ZONE));
        final String strDate = String.format(
                FORMAT,
                hh_mm.format(new Date(time)),
                mm_ss.format(new Date(/*System.currentTimeMillis()*/Calendar.getInstance(TimeZone.getTimeZone("Europe/Moscow")).getTime().getTime() - (new Date(time).getTime())))  //намудрил, но ладно, можно проще сделать, но уже работает.
        );

        post(new Runnable() {
            @Override
            public void run() {
                setText(strDate);
            }
        });
    }

    /**
     * Заставить обновить "поле" без таймера
     */
    public void update() {
        _setTime();
    }

    class MyTimerTask extends TimerTask {
        public MyTimerTask() {
            Log.d(TAG, "new timer of " + timers.size());
            timers.add(timer);
        }

        @Override
        public void run() {
            _setTime();
        }
    }

    @Override
    protected void onDetachedFromWindow() {
        timer.cancel();
        super.onDetachedFromWindow();
    }

    public synchronized void cancel(){
        if(timer != null){
            timer.cancel();
            timers.remove(timer);
        }
    }

    public synchronized static void cancelAll(){
        for(Timer t : timers){
            if(t != null) t.cancel();
        }

        timers.clear();
    }
}
