package ru.ipartner.veep.app.dialog;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import ru.ipartner.veep.app.Controller;
import ru.ipartner.veep.app.R;

/**
 *
 * Created by andrey on 09.12.2015.
 */
public class ConfirmDialog extends Dialog {
    private EditText password;
    private TextView ok;
    private TextView cancel;

    private OnClick listener;

    public ConfirmDialog(Context context) {
        super(context);
    }

    public ConfirmDialog(Context context, int themeResId) {
        super(context, themeResId);
    }

    public ConfirmDialog(Context context, boolean cancelable, OnCancelListener cancelListener) {
        super(context, cancelable, cancelListener);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);

        setContentView(R.layout.dialog_confirm);

        password = (EditText) findViewById(R.id.editTextPassword);
        ok = (TextView) findViewById(R.id.ok);
        cancel = (TextView) findViewById(R.id.cancel);

        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(Controller.getInstance().getProfile() == null) return;   //todo нужно сообщение?
                boolean result = Controller.getInstance().getProfile().adminPsw.equals(password.getText().toString());
                if(result){
                    if(listener != null) listener.onClick(true);
                    dismiss();
                }
                else{
                    Toast.makeText(getContext(), R.string.error_wrong_password, Toast.LENGTH_SHORT).show();
                }
            }
        });

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(listener != null) listener.onClick(false);
                dismiss();
            }
        });
    }

    public void setListener(OnClick listener) {
        this.listener = listener;
    }

    public interface OnClick{
        public void onClick(boolean ok);
    }
}
