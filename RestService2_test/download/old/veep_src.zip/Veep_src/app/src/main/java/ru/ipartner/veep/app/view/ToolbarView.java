package ru.ipartner.veep.app.view;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.*;
import ru.ipartner.veep.app.Controller;
import ru.ipartner.veep.app.R;


/**
 *
 * Created by andrey on 09.12.2015.
 */
public class ToolbarView extends FrameLayout {
    private boolean isBack = false;
    private boolean isTabbed = false;

    private OnTabClickedListener tabClickedListener;

    //UI
    private FrameLayout frameIcon;
    private TextView textTitle;
    private RadioGroup radioTabs;
    private TimeView timeView;
    private ImageView icon;
    private RadioButton tab1;
    private RadioButton tab2;

    private View.OnClickListener clickListener;

    public ToolbarView(Context context) {
        this(context, null);
    }

    public ToolbarView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public ToolbarView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);

        build(attrs);
    }

    private void build(AttributeSet attrs){
        LayoutInflater.from(getContext()).inflate(R.layout.toolbar, this, true);

        frameIcon = (FrameLayout) findViewById(R.id.frameIcon);
        textTitle = (TextView) findViewById(R.id.textTitle);
        radioTabs = (RadioGroup) findViewById(R.id.radioTabs);
        timeView = (TimeView) findViewById(R.id.timeView);
        icon = (ImageView) findViewById(R.id.imageViewIcon);

        tab1 = (RadioButton) findViewById(R.id.radioButton1);
        tab2 = (RadioButton) findViewById(R.id.radioButton2);

        if(!isInEditMode() && !Controller.getInstance().isAdmin()){
            tab2.setVisibility(GONE);
            radioTabs.setWeightSum(1);
        }

        //кликаем иконку
        frameIcon.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if(clickListener != null) clickListener.onClick(v);
            }
        });

        TypedArray a = getContext().getTheme().obtainStyledAttributes(
                attrs,
                R.styleable.ToolbarView,
                0, 0);
        isTabbed = a.getBoolean(R.styleable.ToolbarView_tabbed, isTabbed);
        isBack = a.getBoolean(R.styleable.ToolbarView_back, isBack);

        tab1.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!isTabbed) return;

                tab1.setChecked(true);
                if(tabClickedListener != null) tabClickedListener.onClick(0);
            }
        });

        tab2.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!isTabbed) return;

                tab2.setChecked(true);
                if(tabClickedListener != null) tabClickedListener.onClick(1);
            }
        });

        updateView();
    }

    private void updateView(){
        radioTabs.setVisibility(isTabbed ? VISIBLE : INVISIBLE);
        textTitle.setVisibility(!isTabbed ? VISIBLE : INVISIBLE);

        icon.setImageResource(isBack ? R.drawable.toolbar_back : R.drawable.toolbar_menu);
    }

    public void setTitle(String title){
        textTitle.setText(title);
    }

    public void setIconClickListener(View.OnClickListener clickListener){
        this.clickListener = clickListener;
    }

    public void setTabbed(boolean isTabbed) {
        this.isTabbed = isTabbed;
        updateView();
    }

    public void setBack(boolean isBack) {
        this.isBack = isBack;
    }

    public void setTabClickedListener(OnTabClickedListener tabClickedListener) {
        this.tabClickedListener = tabClickedListener;
    }

    public interface OnTabClickedListener{
        public void onClick(int tab);
    }

}
