package ru.ipartner.veep.app;

import android.app.Application;
import android.test.ApplicationTestCase;
import ru.ipartner.veep.app.helpers.Helper;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

/**
 * <a href="http://d.android.com/tools/testing/testing_android.html">Testing Fundamentals</a>
 */
public class ApplicationTest extends ApplicationTestCase<Application> {
    public ApplicationTest() {
        super(Application.class);
    }

    public void test_date(){
        //String inDate = "2016-02-12T18:04:02";
        //2016-02-12T18:00:44.363
        String inDate = "2016-02-15T11:40:44.363";

        Date d1 = Helper.sharpDateToJavaDate(inDate);
        Date d2 = new Date();

        long sub = d2.getTime()-d1.getTime();
        Date d3 = new Date(sub);
        SimpleDateFormat mm_ss = new SimpleDateFormat(
                "HH:mm:ss");
        mm_ss.setTimeZone(TimeZone.getTimeZone("UTC"));
        String dd = mm_ss.format(d3);
        System.out.println(dd);
    }
}