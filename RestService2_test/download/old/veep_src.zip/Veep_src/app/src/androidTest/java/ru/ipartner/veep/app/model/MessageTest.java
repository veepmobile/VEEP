package ru.ipartner.veep.app.model;

import junit.framework.TestCase;
import static junit.framework.Assert.*;

/**
 * Created by andrey on 01.02.2016.
 */
public class MessageTest extends TestCase {

    public void testRet() throws Exception {
        Message m = new Message(0);
        assertEquals(false, m.ret());
    }
}