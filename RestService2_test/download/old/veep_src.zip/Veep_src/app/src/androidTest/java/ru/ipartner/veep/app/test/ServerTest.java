package ru.ipartner.veep.app.test;

import com.Wsdl2Code.WebServices.Rest.Personal;
import com.Wsdl2Code.WebServices.Rest.Profile;
import com.Wsdl2Code.WebServices.Rest.Rest;
import junit.framework.TestCase;
import ru.ipartner.veep.app.Consts;

import java.io.IOException;

/**
 * Created by andrey on 04.02.2016.
 */
public class ServerTest extends TestCase{
    public static final String WAITER_LOGIN = "luce_cash";
    public static final String WAITER_PASS = WAITER_LOGIN;
    private Rest rest;

    @Override
    protected void setUp() throws Exception {
        super.setUp();

        rest = new Rest();
        rest.setUrl("http://185.26.113.204/Rest.svc/soap");
        rest.setTimeOut(Consts.REST_TIMEOUT);
    }

    public void test_PersonalLogin_admin() throws IOException {
        Personal p = rest.PersonalLogin("luce_adm", "lucecafe");
        assertNotNull(p);
        assertEquals(p.rolesID, Consts.Roles.ADMIN);
    }

    public void test_PersonalLogin_waiter() throws IOException {
        Personal p = rest.PersonalLogin(WAITER_LOGIN, WAITER_PASS);
        assertNotNull(p);
        assertEquals(p.rolesID, Consts.Roles.OFFICIANT);
    }

    public void test_PswRemember_waiter(){
        //rest.PswRemember("luce_adm");
        Integer ret = rest.PswRemember("luce_cash");
        assertNotNull(ret);
        assertEquals(true, 2 == ret);
    }

    public void test_PswRemember_wrong(){
        //rest.PswRemember("luce_adm");
        Integer ret = rest.PswRemember("ablablabla");
        assertNotNull(ret);
        assertEquals(true, 1 == ret);
    }

    public void test_GetProfile(){
        Profile p = rest.GetProfile(202930001, true);
        assertNotNull(p);
    }

    public void test_GetProfile_wrong(){
        Profile p = rest.GetProfile(2, true);
        assertEquals(true, null == p);
    }

    public void test_ChangePersonalPsw() throws IOException {
        Personal p = rest.PersonalLogin(WAITER_LOGIN, WAITER_PASS);
        assertNotNull(p);
        Integer ret = rest.ChangePersonalPsw(p.iD, true, WAITER_PASS);
        assertNotNull(ret);
        assertEquals(true, 1 == ret);
    }

    public void test_GetMessages_main() throws IOException {
        Personal p = rest.PersonalLogin(WAITER_LOGIN, WAITER_PASS);
        assertNotNull(p);
        Profile pr = rest.GetProfile(p.restaurantID, true);
        assertNotNull(pr);
        rest.GetMessages(pr.restaurantID, true, Consts.MessagesMode.GENERAL, true);
        //todo доделать как только будет работать
    }

    public void test_GetMessages_other() throws IOException {
        Personal p = rest.PersonalLogin(WAITER_LOGIN, WAITER_PASS);
        assertNotNull(p);
        Profile pr = rest.GetProfile(p.restaurantID, true);
        assertNotNull(pr);
        rest.GetMessages(pr.restaurantID, true, Consts.MessagesMode.OTHER, true);
        //todo доделать как только будет работать
    }

    public void test_ReadMessage_wrong(){
        /*Integer ret = rest.ReadMessage(1, true, 1, true);
        assertNotNull(ret);
        assertEquals(true, 0 == ret);*/
    }

    public void test_GetHistory() throws IOException {
        Personal p = rest.PersonalLogin(WAITER_LOGIN, WAITER_PASS);
        assertNotNull(p);
        Profile pr = rest.GetProfile(p.restaurantID, true);
        assertNotNull(pr);
        rest.GetHistoryPayments(pr.restaurantID, true);
        //todo доделать, когда будет работать
    }
}
