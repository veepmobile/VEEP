package ru.ipartner.veep.app.test;

import junit.framework.TestCase;

/**
 * Created by andrey on 01.02.2016.
 */
public class myTest extends TestCase {
    public void test1(){
        throw new RuntimeException("blabla");
    }

    public void test2(){

    }
}
