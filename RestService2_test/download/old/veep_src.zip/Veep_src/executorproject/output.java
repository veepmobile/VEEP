package ru.ipartner.veep.app.test;

import ru.ipartner.veep.app.activity.LoginActivity;
import com.robotium.solo.*;
import android.test.ActivityInstrumentationTestCase2;


public class first extends ActivityInstrumentationTestCase2<LoginActivity> {
  	private Solo solo;
  	
  	public first() {
		super(LoginActivity.class);
  	}

  	public void setUp() throws Exception {
        super.setUp();
		solo = new Solo(getInstrumentation());
		getActivity();
  	}
  
   	@Override
   	public void tearDown() throws Exception {
        solo.finishOpenedActivities();
        super.tearDown();
  	}
  
	public void testRun() {
        //Wait for activity: 'ru.ipartner.veep.app.activity.LoginActivity'
		solo.waitForActivity(ru.ipartner.veep.app.activity.LoginActivity.class, 2000);
        //Set default small timeout to 13544 milliseconds
		Timeout.setSmallTimeout(13544);
        //Click on Empty Text View
		solo.clickOnView(solo.getView(ru.ipartner.veep.app.R.id.editTextLogin));
        //Enter the text: '12'
		solo.clearEditText((android.widget.EditText) solo.getView(ru.ipartner.veep.app.R.id.editTextLogin));
		solo.enterText((android.widget.EditText) solo.getView(ru.ipartner.veep.app.R.id.editTextLogin), "12");
        //Click on Empty Text View
		solo.clickOnView(solo.getView(ru.ipartner.veep.app.R.id.editTextPassword));
        //Enter the text: '33'
		solo.clearEditText((android.widget.EditText) solo.getView(ru.ipartner.veep.app.R.id.editTextPassword));
		solo.enterText((android.widget.EditText) solo.getView(ru.ipartner.veep.app.R.id.editTextPassword), "33");
        //Click on ��������� ������
		solo.clickOnView(solo.getView(ru.ipartner.veep.app.R.id.textViewRemind));
        //Click on �����
		solo.clickOnView(solo.getView(ru.ipartner.veep.app.R.id.textViewEnter));
        //Wait for activity: 'ru.ipartner.veep.app.MainActivity'
		assertTrue("ru.ipartner.veep.app.MainActivity is not found!", solo.waitForActivity(ru.ipartner.veep.app.MainActivity.class));
        //Click on �������
		solo.clickOnView(solo.getView(ru.ipartner.veep.app.R.id.radioButton2));
        //Click on ���������
		solo.clickOnView(solo.getView(ru.ipartner.veep.app.R.id.radioButton1));
        //Click on �������
		solo.clickOnView(solo.getView(ru.ipartner.veep.app.R.id.radioButton2));
        //Click on ���������
		solo.clickOnView(solo.getView(ru.ipartner.veep.app.R.id.radioButton1));
        //Click on ��
		solo.clickOnView(solo.getView(ru.ipartner.veep.app.R.id.ok));
        //Click on ��
		solo.clickOnView(solo.getView(ru.ipartner.veep.app.R.id.ok, 1));
        //Click on ��
		solo.clickOnView(solo.getView(ru.ipartner.veep.app.R.id.ok, 2));
        //Scroll to 1st ListView
		android.widget.ListView listView0 = (android.widget.ListView) solo.getView(android.widget.ListView.class, 0);
		solo.scrollListToLine(listView0, 4);
        //Scroll to �������
		android.widget.ListView listView1 = (android.widget.ListView) solo.getView(android.widget.ListView.class, 1);
		solo.scrollListToLine(listView1, 0);
        //Click on �������
		solo.clickOnView(solo.getView(ru.ipartner.veep.app.R.id.radioButton2));
        //Click on FrameLayout
		solo.clickOnView(solo.getView(ru.ipartner.veep.app.R.id.frameIcon));
        //Click on ���������� ��������
		solo.clickOnView(solo.getView(ru.ipartner.veep.app.R.id.drawerItem1));
        //Wait for activity: 'ru.ipartner.veep.app.activity.ControlActivity'
		assertTrue("ru.ipartner.veep.app.activity.ControlActivity is not found!", solo.waitForActivity(ru.ipartner.veep.app.activity.ControlActivity.class));
        //Click on 9035555555
		solo.clickOnView(solo.getView(ru.ipartner.veep.app.R.id.editTextPhone));
        //Enter the text: '903555ff5555'
		solo.clearEditText((android.widget.EditText) solo.getView(ru.ipartner.veep.app.R.id.editTextPhone));
		solo.enterText((android.widget.EditText) solo.getView(ru.ipartner.veep.app.R.id.editTextPhone), "903555ff5555");
        //Click on aQ23F
		solo.clickOnView(solo.getView(ru.ipartner.veep.app.R.id.editTextPassword));
        //Enter the text: 'aQ23Fdd'
		solo.clearEditText((android.widget.EditText) solo.getView(ru.ipartner.veep.app.R.id.editTextPassword));
		solo.enterText((android.widget.EditText) solo.getView(ru.ipartner.veep.app.R.id.editTextPassword), "aQ23Fdd");
        //Click on ���������
		solo.clickOnView(solo.getView(ru.ipartner.veep.app.R.id.textViewApply));
        //Wait for dialog
		solo.waitForDialogToOpen(5000);
        //Click on ������
		solo.clickOnView(solo.getView(ru.ipartner.veep.app.R.id.cancel));
        //Click on ���������
		solo.clickOnView(solo.getView(ru.ipartner.veep.app.R.id.textViewApply));
        //Wait for dialog
		solo.waitForDialogToOpen(5000);
        //Click on OK
		solo.clickOnView(solo.getView(ru.ipartner.veep.app.R.id.ok));
        //Click on ������ ����� ������
		solo.clickOnView(solo.getView(ru.ipartner.veep.app.R.id.textViewSetPassword));
        //Wait for dialog
		solo.waitForDialogToOpen(5000);
        //Click on ������
		solo.clickOnView(solo.getView(ru.ipartner.veep.app.R.id.cancel));
        //Click on ������ ����� ������
		solo.clickOnView(solo.getView(ru.ipartner.veep.app.R.id.textViewSetPassword));
        //Wait for dialog
		solo.waitForDialogToOpen(5000);
        //Click on ���������
		solo.clickOnView(solo.getView(ru.ipartner.veep.app.R.id.ok));
        //Click on FrameLayout
		solo.clickOnView(solo.getView(ru.ipartner.veep.app.R.id.frameIcon));
        //Click on FrameLayout
		solo.clickOnView(solo.getView(ru.ipartner.veep.app.R.id.frameIcon));
        //Click on �����
		solo.clickOnView(solo.getView(ru.ipartner.veep.app.R.id.drawerItem2));
	}
}
