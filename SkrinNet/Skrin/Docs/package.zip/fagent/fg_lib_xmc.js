function insert_list_elem( screen, array )
{
	selector = screen.FindItem( '__fa_selector' );
	page = selector.InnerItem;

	try
	{
		grid = page.FindSubItemByType( 'GRID' );
	}
	catch ( e )
	{
		return;
	}

	curIndex = undefined;

	if ( grid.HasSel )
	{
		try
		{
			curElem = grid.SelRow.Env.ListElem;
			curIndex = curElem.ChildIndex;
		}
		catch ( e )
		{
		}
	}

	elem = array.Add();

	if ( curIndex != undefined )
		elem.SetChildIndex( curIndex );

	grid.Env.OpenInnerPage( elem );
}


function handle_list_paste( grid, array )
{
	if ( ! ClipboardFormatAvailable( 'text/xml' ) )
		return;
	
	srcDoc = OpenDocFromStr( GetClipboard( 'text/xml' ) );
	//alert( srcDoc.TopElem.Xml );

	if ( ! array.IsMultiElem )
	{
		formElem = ArrayOptFind( array.FormElem, 'IsMultiple' );
		if ( formElem == undefined )
			return;
		
		array = GetObjectProperty( array, formElem.Name );
	}
	
	//alert( array.Name );
	
	for ( srcElem in srcDoc.TopElem )
	{
		elem = ( array.IsMultiElem ? array.Add() : array.AddChild() );
		//elem.AssignElem( srcElem );
		elem.LoadData( srcElem.Xml );
	}
	
	array.Doc.UpdateValues();
	grid.Screen.Update();
}


function handle_copy_section( screen, elem )
{
	//alert( elem.Name );
	SetClipboard( '<elems>' + elem.Xml + '</elems>', 'text/xml' )
}


function handle_paste_section( screen, elem )
{
	//alert( elem.Name );

	if ( ! ClipboardFormatAvailable( 'text/xml' ) )
		return;

	srcDoc = OpenDocFromStr( GetClipboard( 'text/xml' ) );
	//alert( srcDoc.TopElem.Xml );

	for ( srcElem in srcDoc.TopElem )
	{
		elem.LoadData( srcElem.Xml );
		break;
	}
	
	elem.Doc.UpdateValues();
	//grid.Screen.Update();
}


function handle_load_attachment( attachment )
{
	fileUrl = ActiveScreen.AskFileOpen();
	
	attachment.data.LoadFromFile( fileUrl );
	attachment.file_name = UrlFileName( fileUrl );

	attachment.Doc.SetChanged( true );
}


function handle_open_attachment( attachment, screen )
{
	editor = OpenNewDoc( 'fa_attachment_editor.xmd' ).TopElem;
	editor.init( attachment );

	screen.AddExternalEditor( editor );
}


function handle_clear_attachment( attachment, screen )
{
	attachment.Clear();
}